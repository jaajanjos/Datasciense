@echo off
rem Blog das maquinas (Google Sites): abre o painel de manutencao no navegador
start "" "%~dp01_PROGRAMAS\Blog_Maquinas\painel-manutencao-anuncios.html"
