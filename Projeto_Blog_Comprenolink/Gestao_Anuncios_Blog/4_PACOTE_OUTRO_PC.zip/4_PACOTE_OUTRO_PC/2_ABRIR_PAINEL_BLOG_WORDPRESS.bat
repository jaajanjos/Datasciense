@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Painel do blog comprenolink.net (WordPress). NAO feche esta janela enquanto usar o painel.
"1_PROGRAMAS\Blog_WordPress\PainelBlog.exe"
pause
