@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================================
echo   PUBLICAR AS CATEGORIAS DO BLOG comprenolink.net
echo ================================================================
echo Antes de publicar, o programa mostra o PLANO (nao muda nada no site).
echo Precisa do arquivo 2_DADOS\Blog_WordPress\wp_credenciais.json (a senha deste PC).
echo.
echo --- PLANO (nada e publicado) ---
"1_PROGRAMAS\Blog_WordPress\PublicarCategorias.exe"
if errorlevel 1 (echo. & echo ERRO no plano. Nada foi publicado. & pause & exit /b 1)
echo.
echo ATENCAO: publicar atualiza no site as paginas de categoria, Black Friday/Natal, o guia, a Inicio e o menu.
echo O programa guarda backup de cada pagina em 2_DADOS\Blog_WordPress\backups antes de mudar.
set "OK="
set /p "OK=Publicar agora? (S/N): "
if /i not "%OK%"=="S" (echo Cancelado. Nada foi publicado. & pause & exit /b 0)
"1_PROGRAMAS\Blog_WordPress\PublicarCategorias.exe" --publicar
echo.
echo Se o site nao mudar na hora, limpe o cache (LiteSpeed ^> Limpar tudo).
pause
