@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "ORIGEM=%~dp0arquivos"
set "DESTINO=%~1"
echo ================================================================
echo   ATUALIZAR OS PAINEIS DOS BLOGS  (versao 08/11/2026 13h34)
echo   Troca so os programas. NAO mexe na senha nem nos backups.
echo ================================================================
echo.
if not exist "%ORIGEM%\1_PROGRAMAS\Blog_WordPress\PainelBlog.exe" (
  echo ERRO: extraia o .zip antes ^(botao direito ^> Extrair tudo^) e rode o ATUALIZAR_AQUI.bat de dentro da pasta extraida.
  goto fim
)
if defined DESTINO goto confere
for %%P in ("C:\4_PACOTE_OUTRO_PC" "C:\Blog_Manutencao" "C:\Blog_Manutencao\4_PACOTE_OUTRO_PC" "D:\4_PACOTE_OUTRO_PC" "%USERPROFILE%\Desktop\4_PACOTE_OUTRO_PC" "%USERPROFILE%\Documents\4_PACOTE_OUTRO_PC" "%USERPROFILE%\OneDrive\Desktop\4_PACOTE_OUTRO_PC") do (
  if not defined DESTINO if exist "%%~P\2_ABRIR_PAINEL_BLOG_WORDPRESS.bat" set "DESTINO=%%~P"
)
if defined DESTINO goto confere
echo Nao achei a pasta do painel sozinho.
echo Arraste para esta janela a pasta do painel (a que tem 2_ABRIR_PAINEL_BLOG_WORDPRESS.bat)
set /p "DESTINO=e aperte Enter: "
set "DESTINO=%DESTINO:"=%"
:confere
if "%DESTINO:~-1%"=="\" set "DESTINO=%DESTINO:~0,-1%"
if not exist "%DESTINO%\2_ABRIR_PAINEL_BLOG_WORDPRESS.bat" (
  echo ERRO: "%DESTINO%" nao e a pasta do painel ^(falta 2_ABRIR_PAINEL_BLOG_WORDPRESS.bat^). Nada foi alterado.
  goto fim
)
if exist "%DESTINO%\..\ATUALIZAR_AQUI.bat" (
  echo ERRO: essa e a pasta da propria atualizacao. Escolha a pasta do painel instalado. Nada foi alterado.
  goto fim
)
echo Pasta do painel: %DESTINO%
if exist "%DESTINO%\2_DADOS\Blog_WordPress\wp_credenciais.json" (echo Senha deste PC: encontrada, sera mantida) else (echo Senha deste PC: ainda nao cadastrada)
echo.
set "OK="
set /p "OK=Atualizar agora? (S/N): "
if /i not "%OK%"=="S" (echo Cancelado. Nada foi alterado. & goto fim)
echo.
echo Fechando o painel do WordPress, se estiver aberto...
taskkill /im PainelBlog.exe /f >nul 2>&1
ping -n 3 127.0.0.1 >nul
echo Copiando os programas novos...
robocopy "%ORIGEM%" "%DESTINO%" /E /XD 2_DADOS /XF wp_credenciais.json /R:3 /W:2 /NJH /NJS /NP /NFL /NDL >nul
if errorlevel 8 (
  echo ERRO ao copiar ^(algum arquivo em uso?^). Feche o painel e rode de novo. Seus dados nao foram tocados.
  goto fim
)
if not exist "%DESTINO%\2_DADOS\Blog_Maquinas" mkdir "%DESTINO%\2_DADOS\Blog_Maquinas"
if not exist "%DESTINO%\2_DADOS\Blog_WordPress\backups" mkdir "%DESTINO%\2_DADOS\Blog_WordPress\backups"
if not exist "%DESTINO%\2_DADOS\Blog_WordPress\wp_credenciais.exemplo.json" copy "%~dp0modelo\wp_credenciais.exemplo.json" "%DESTINO%\2_DADOS\Blog_WordPress\" >nul
echo.
echo PRONTO: programas atualizados para a versao 08/11/2026 13h34.
if exist "%DESTINO%\2_DADOS\Blog_WordPress\wp_credenciais.json" (echo Senha e backups: mantidos.) else (echo Falta a senha: abra o atalho 2 e siga o passo 3 do LEIA-ME_COMO_INSTALAR_NO_OUTRO_PC.txt)
echo Abra o 2_ABRIR_PAINEL_BLOG_WORDPRESS.bat para conferir ^(deve aparecer "Conectado"^).
echo Depois pode apagar a pasta desta atualizacao.
:fim
echo.
pause
