import json, shutil, sys, os
from datetime import datetime
f = sys.argv[1]
bk = os.path.join(os.path.dirname(f), "backups", f"categorias_{datetime.now():%Y-%m-%d_%Hh%M%S}.json")
shutil.copy2(f, bk); print("backup:", bk)
d = json.load(open(f, encoding="utf-8"))
cats = d["categorias"]
if not any(c["slug"] == "bebe-e-maternidade" for c in cats):
    bebe = {
        "nome": "Bebê & Maternidade", "slug": "bebe-e-maternidade", "emoji": "🍼",
        "intro": "Enxoval, mantas, sacos de dormir, trocadores, naninhas e móbiles para os primeiros meses do bebê, selecionados entre os mais vendidos e bem avaliados do Mercado Livre.",
        "chamada": "enxoval, mantas, trocadores e naninhas",
        "meta_descricao": "Enxoval de bebê, saída maternidade, saco de dormir, trocador de fralda, naninhas e móbiles para berço: os mais vendidos do Mercado Livre.",
        "subcategorias": [
            {"nome": "Trocadores & Higiene", "palavras": ["trocador", "kit higiene", "kit cuidados"]},
            {"nome": "Naninhas & Móbiles", "palavras": ["naninha", "naninhas", "móbile", "mobile musical"]},
            {"nome": "Enxoval & Mantas", "palavras": ["saída maternidade", "saco de dormir", "ninho para bebê", "kit enxoval", "manta bebê", "cobertor enroladinho", "bebê", "bebe"]},
        ],
    }
    i = next(k for k, c in enumerate(cats) if c["slug"] == "casa-cama-e-decoracao")
    cats.insert(i, bebe)  # antes de Casa, Cama & Decoração (que tem "manta" e "cobertor")
assert len(bebe["meta_descricao"]) <= 160 if "bebe" in dir() else True
beleza = next(c for c in cats if c["slug"] == "beleza-e-saude")
v = next(s for s in beleza["subcategorias"] if s["nome"] == "Vitaminas & Suplementos")
v["palavras"] += [p for p in ["licopeno", "óleo de semente", "kit 2 óleo de semente"] if p not in v["palavras"]]
tags = {t["tag"]: t for t in d["tags"]}
tags["natal-presentes"]["palavras"] += [p for p in ["naninha", "manta bebê personalizada"] if p not in tags["natal-presentes"]["palavras"]]
json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("ok")
