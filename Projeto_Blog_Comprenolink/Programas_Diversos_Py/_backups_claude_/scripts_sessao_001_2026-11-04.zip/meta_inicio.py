op = [
 "Celulares, Smart TVs, fones, ferramentas, enxoval, perfumes e fitness: ofertas selecionadas do Mercado Livre, organizadas por categoria para você escolher rápido.",
 "Achados do Mercado Livre em um só lugar: tecnologia, áudio e TV, casa, cama e decoração, ferramentas, beleza e fitness. Compare e garanta o seu com 1 clique.",
 "Ofertas do Mercado Livre escolhidas a dedo: celulares, Smart TVs, eletroportáteis, perfumes e muito mais, separados por categoria e com página de Black Friday.",
]
for i,t in enumerate(op,1): print(i, len(t))
