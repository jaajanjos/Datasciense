import sys; sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
from gerar_esboco_categorias import carrega_arvore, classifica, tags_do
arv = carrega_arvore()
if "--arvore" in sys.argv:
    for c in arv["categorias"]:
        print(c["slug"])
        for s in c["subcategorias"]: print("   ", s["nome"], ":", s["palavras"])
    for t in arv["tags"]: print("TAG", t["tag"], t["palavras"])
it = g.itens(g.baixar_pagina(g.carregar_config()).conteudo)
ini = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 86
for x in it:
    if x["n"] >= ini:
        (c, s), t = classifica(x, arv), tags_do(x, arv)
        print(x["n"], x["nome"], "=>", c and c["nome"], "/", s and s["nome"], t)
