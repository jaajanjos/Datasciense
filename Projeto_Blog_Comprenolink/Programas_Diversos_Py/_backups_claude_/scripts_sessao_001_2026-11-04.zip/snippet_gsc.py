import sys, json; sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
cfg = g.carregar_config()
codigo = """// Verificação do Google Search Console (conta compre.no.link26@gmail.com). NÃO APAGAR: sem ela o site perde a verificação.
add_action('wp_head', function () {
    echo '<meta name="google-site-verification" content="RWQj_SBlJgz6nB0INaWk1RZC1WneQ3VhHvSK-IMmoOM" />' . "\n";
}, 1);"""
r = g.requisitar(cfg, "POST", "/wp-json/code-snippets/v1/snippets",
                 {"name": "Verificação Google Search Console", "code": codigo, "scope": "front-end", "active": True,
                  "desc": "Meta tag de verificação do Search Console (comprenolink.net). Não apagar."})
print(r.get("id"), r.get("name"), r.get("active"), r.get("code_error"))
