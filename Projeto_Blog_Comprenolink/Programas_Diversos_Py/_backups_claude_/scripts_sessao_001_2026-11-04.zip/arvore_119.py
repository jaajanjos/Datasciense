import json, shutil, sys, os
from datetime import datetime
f = sys.argv[1]
bk = os.path.join(os.path.dirname(f), "backups", f"categorias_{datetime.now():%Y-%m-%d_%Hh%M%S}.json")
shutil.copy2(f, bk); print("backup:", bk)
d = json.load(open(f, encoding="utf-8"))
cat = {c["slug"]: c for c in d["categorias"]}
sub = lambda slug, nome: next(s for s in cat[slug]["subcategorias"] if s["nome"] == nome)
def add(slug, nome, *pal):
    s = sub(slug, nome)
    s["palavras"] += [p for p in pal if p not in s["palavras"]]
def nova(slug, depois_de, nome, pal):
    subs = cat[slug]["subcategorias"]
    i = subs.index(sub(slug, depois_de))
    subs.insert(i + 1, {"nome": nome, "palavras": pal})

# Tecnologia: impressoras são periféricos
add("tecnologia-e-informatica", "Periféricos", "impressora", "mini impressora")
t = cat["tecnologia-e-informatica"]
t["intro"] = "Confira as melhores ofertas de notebooks, monitores, impressoras, celulares, smartwatches e periféricos gamer, selecionados entre os mais vendidos e bem avaliados do Mercado Livre."
t["chamada"] = "notebooks, celulares, impressoras e periféricos gamer"
t["meta_descricao"] = "Notebook ASUS Ryzen 7, monitor LG 27\", impressora EcoTank, SSD NVMe, celulares e periféricos gamer: tecnologia com ótimo custo-benefício no Mercado Livre."
# Áudio & TV: receptor de parabólica junto das TVs
s = sub("audio-e-tv", "Smart TVs"); s["nome"] = "TVs & Receptores"; s["palavras"] += ["receptor"]
a = cat["audio-e-tv"]
a["intro"] = "Som e imagem de qualidade para a sua casa: fones, caixas de som, soundbars, Smart TVs, receptores e telas de projeção com melhor custo-benefício do Mercado Livre."
a["meta_descricao"] = "JBL Go 5 e Boombox, caixas amplificadas, soundbar, Smart TVs Samsung e Philco Roku e receptor sem mensalidade: som e imagem com ofertas do Mercado Livre."
# Casa & Eletrodomésticos: kit festa de acrílico vai para a mesa
add("casa-e-eletrodomesticos", "Utensílios, Cozinha & Mesa", "kit festa", "boleira")
# Casa, Cama & Decoração
add("casa-cama-e-decoracao", "Cama & Descanso", "coberta", "capas protetoras de travesseiro")
add("casa-cama-e-decoracao", "Decoração & Iluminação", "solitário", "solitários")
cat["casa-cama-e-decoracao"]["meta_descricao"] = "Jogo de lençol 600 fios, coberta sherpa, travesseiro ergonômico, cabeceira e decoração de Natal: conforto e estilo para a casa com ofertas do Mercado Livre."
# Ferramentas & Utilidades
add("ferramentas-e-utilidades", "Ferramentas Elétricas", "compressor", "mini compressor", "soprador", "mini soprador", "motosserra", "mini motosserra")
add("ferramentas-e-utilidades", "Ferramentas Manuais", "jogo de bits", "bits")
nova("ferramentas-e-utilidades", "Ferramentas Manuais", "Reparos & Vedação", ["silicone", "cola", "veda"])
cat["ferramentas-e-utilidades"]["intro"] = "Ferramentas, reparos, limpeza e organização que resolvem a rotina da casa, com as melhores ofertas do Mercado Livre."
cat["ferramentas-e-utilidades"]["meta_descricao"] = "Parafusadeiras, mini motosserra WAP, compressor Tramontina, jogo de bits Vonder, silicone e organizadores: ferramentas e utilidades com ofertas do Mercado Livre."
# Esporte & Fitness
add("esporte-e-fitness", "Treino em Casa", "bicicleta ergométrica", "mini bike")
add("esporte-e-fitness", "Moda Fitness", "maiô", "macaquinho")
nova("esporte-e-fitness", "Moda Fitness", "Proteção & Suporte", ["joelheira", "joelheiras", "tornozeleira"])
cat["esporte-e-fitness"]["intro"] = "Treine em casa, vista-se para o treino, proteja as articulações e mantenha a suplementação em dia com os produtos fitness mais procurados no Mercado Livre."
cat["esporte-e-fitness"]["meta_descricao"] = "Whey, creatina, bicicleta ergométrica, mini bike, leggings, maiô de natação e joelheiras entre os mais vendidos do Mercado Livre. Treine melhor e veja as ofertas!"
# Beleza & Saúde
add("beleza-e-saude", "Skincare", "gel hidratante", "hidratante facial")
add("beleza-e-saude", "Cuidados Pessoais", "óleo extraordinário", "leave-in")
cat["beleza-e-saude"]["meta_descricao"] = "Perfumes árabes, sérum de retinol, protetor solar FPS 70, kit vitamina C, colágeno e óleo Elseve: beleza e cuidado no dia a dia com ofertas do Mercado Livre."
# Tags
tags = {x["tag"]: x for x in d["tags"]}
def tag(nome, *pal):
    tags[nome]["palavras"] += [p for p in pal if p not in tags[nome]["palavras"]]
tag("black-friday", "notebook asus", "impressora multifuncional", "bicicleta ergométrica")
tag("natal-presentes", "óleo extraordinário", "solitários")
tag("treino-em-casa", "bicicleta ergométrica", "mini bike")
tag("gamer", "monitor")
tag("volta-as-aulas", "notebook", "impressora", "mini impressora de etiquetas")
tag("verao", "protetor solar", "maiô")
tag("casa-inteligente", "caixa de som inteligente")
tag("apartamento", "mini bike")
json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("ok")
