# Página Contato (id 19) com botão do WhatsApp. Sem argumento: só prévia local. --publicar: publica com backup.
import os, re, subprocess, sys, urllib.request
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
from publicar_categorias import renderiza, salva_backup

WA = "https://wa.me/5511994959657?text=Ol%C3%A1%21%20Vim%20pelo%20site%20comprenolink.net"
NOVO = f"""<!-- wp:paragraph -->
<p>Tem uma dúvida, quer o link de algum produto ou encontrou um anúncio fora do ar? Fale com a gente pelo WhatsApp ou por e-mail. Respondemos o mais rápido possível.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {{"style":{{"color":{{"background":"#25d366","text":"#ffffff"}}}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-text-color has-background wp-element-button" href="{WA}" style="color:#ffffff !important;background:#25d366 !important;box-shadow:0 6px 16px rgba(37,211,102,.35) !important" target="_blank" rel="noreferrer noopener">💬 Falar no WhatsApp</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="mailto:compre.no.link26@gmail.com?subject=Contato%20pelo%20site%20Compre%20no%20Link">✉️ Enviar e-mail</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph -->
<p>WhatsApp: <strong>(11) 99495-9657</strong><br>E-mail: <strong>compre.no.link26@gmail.com</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><em>Dúvidas sobre pedido, pagamento ou entrega devem ser resolvidas diretamente no Mercado Livre, em Minhas compras.</em></p>
<!-- /wp:paragraph -->
"""
cfg = g.carregar_config()
if "--publicar" in sys.argv:
    d = g.requisitar(cfg, "GET", "/wp-json/wp/v2/pages/19?context=edit")
    print("backup:", salva_backup("pagina19_contato", d["content"]["raw"]))
    g.requisitar(cfg, "POST", "/wp-json/wp/v2/pages/19", {"content": NOVO})
    print("publicado")
else:
    S = os.path.dirname(os.path.abspath(__file__))
    pag = urllib.request.urlopen(urllib.request.Request("https://comprenolink.net/contato/", headers={"User-Agent": "previa"}), timeout=60).read().decode()
    m = re.search(r'(<div class="single-entry-summary">)(.*?)(</div>\s*<div id="comments")', pag, re.S)
    html = pag[:m.start(2)] + renderiza(NOVO).replace('<p>', '<p class="wp-block-paragraph">') + pag[m.end(2):]
    arq = os.path.join(S, "previa_contato.html"); open(arq, "w", encoding="utf-8").write(html)
    png = os.path.join(S, "previa_contato.png")
    subprocess.run([r"C:\Program Files\Google\Chrome\Application\chrome.exe", "--headless=new", "--disable-gpu", "--hide-scrollbars",
                    "--window-size=1280,1000", "--user-data-dir=" + os.path.join(S, "chr3"), "--screenshot=" + png,
                    "file:///" + arq.replace("\\", "/")], capture_output=True, timeout=120)
    print(png)
