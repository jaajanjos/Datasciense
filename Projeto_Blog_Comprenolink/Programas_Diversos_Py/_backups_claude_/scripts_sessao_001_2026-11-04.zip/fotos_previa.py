import subprocess, os, pathlib
from PIL import Image
S = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(S, "fotos_previa"); os.makedirs(out, exist_ok=True)
C = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
P = r"D:\mercado_livre\Manutenção_Blog\3_DOCUMENTACAO\Blog_WordPress\previa_campanha"
for dia, slug, alt in [("2026-10-26", "inicio", 1700), ("2026-10-26", "black-friday", 3600), ("2026-10-26", "tecnologia-e-informatica", 1100),
                       ("2026-12-01", "presentes-de-natal", 2600), ("2026-12-01", "black-friday", 1100), ("2026-12-01", "inicio", 1100)]:
    png = os.path.join(out, f"{dia}_{slug}.png")
    subprocess.run([C, "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--window-size=1280,{alt}", "--virtual-time-budget=15000",
                    "--user-data-dir=" + os.path.join(S, "chr"), "--screenshot=" + png, pathlib.Path(P, dia, slug + ".html").as_uri()],
                   capture_output=True, timeout=180)
    im = Image.open(png).convert("RGB"); jpg = png[:-4] + ".jpg"; im.save(jpg, quality=80)
    im.save(os.path.join(P, dia, slug + ".jpg"), quality=80); print(jpg)
