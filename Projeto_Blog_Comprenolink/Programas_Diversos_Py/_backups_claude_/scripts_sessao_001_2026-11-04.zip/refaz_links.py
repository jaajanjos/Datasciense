import sys, os, shutil, re
from datetime import date
FONTE = "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte"
sys.path.insert(0, FONTE); os.chdir(FONTE)
import dados_divulgacao as dd
import gerar_artes_catalogo as ga
BK = os.path.join(os.path.dirname(ga.PACOTE), "_backup_pacotes")
DEST = "D:/mercado_livre/4- Celular_Whatsapp/07_PACOTE_DO_DIA"
dados = dd.carrega_produtos()
# Pipoqueira fixa em 16/12 (posição 6 da lista de Natal), localizada pelo nome (o número do item muda)
pip = [x for x in dados["itens"] if "Pipoqueira" in x["nome"] and "Popflix" in x["nome"]]
if pip:
    nat = [x for x in dados["natal"] if x["n"] != pip[0]["n"]]
    nat.insert(6, pip[0]); dados["natal"] = nat
print("Pipoqueira no item", pip[0]["n"] if pip else None)
orig = dd.calendario
nome = lambda d: f"{d:%Y-%m-%d}_{ga.DIAS[d.weekday()]}"
txt = lambda p: open(os.path.join(p, "1_TEXTOS_DO_DIA.txt"), encoding="utf-8-sig").read()
titulo = lambda t: re.search(r"[🔥🎄]\s*([^\n]+)", t.split("Post no feed", 1)[1]).group(1).strip() if "Post no feed" in t else None
dias = sorted({l["data"] for l in orig(dados) if l["item"]})
ok, mud, sem = [], [], []
for d in dias:
    p = os.path.join(ga.PACOTE, nome(d))
    if not os.path.isdir(p):
        sem.append(d); continue
    antes = txt(p); ant = titulo(antes)
    bk = os.path.join(BK, nome(d) + "_01nov_ANTES_links")
    if not os.path.exists(bk):
        shutil.copytree(p, bk)
    f = lambda dados_, d=d: [l for l in orig(dados_) if l["data"] == d]
    dd.calendario = f; ga.dd.calendario = f
    ga.gera_pacotes(dados)
    novo = txt(p)
    if titulo(novo) != ant:
        mud.append((d, ant, titulo(novo)))
        shutil.rmtree(p); shutil.copytree(bk, p); continue
    ancs = sorted(set(re.findall(r"#item-(\d+)", antes))), sorted(set(re.findall(r"#item-(\d+)", novo)))
    shutil.copytree(p, os.path.join(DEST, nome(d)), dirs_exist_ok=True)
    ok.append((d, ant[:30], ancs[0], ancs[1]))
dd.calendario = orig
print("REFEITOS:", len(ok))
for d, t, a, n in ok:
    print(f"  {d:%d/%m} {t:30} ancora {a} -> {n}")
print("PRODUTO MUDOU (restaurado):", mud)
print("SEM PASTA:", sem)
