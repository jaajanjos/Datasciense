import sys, os, shutil
from datetime import date
FONTE = "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte"
sys.path.insert(0, FONTE); os.chdir(FONTE)
import dados_divulgacao as dd
import gerar_artes_catalogo as ga
import gerar_reels
BK = os.path.join(os.path.dirname(ga.PACOTE), "_backup_pacotes")
DEST = "D:/mercado_livre/4- Celular_Whatsapp/07_PACOTE_DO_DIA"
dados = dd.carrega_produtos()
orig = dd.calendario
nome = lambda d: f"{d:%Y-%m-%d}_{ga.DIAS[d.weekday()]}"
def txt(p):
    return open(os.path.join(p, "1_TEXTOS_DO_DIA.txt"), encoding="utf-8-sig").read()
for d in (date(2026, 11, 24), date(2026, 11, 25)):
    p = os.path.join(ga.PACOTE, nome(d))
    bk = os.path.join(BK, nome(d) + "_31out_ANTES_aiwa_philco")
    if not os.path.exists(bk):
        shutil.copytree(p, bk)
    ant = txt(p).split("🔥", 1)[1].split("\n")[0].strip()
    f = lambda dados_, d=d: [l for l in orig(dados_) if l["data"] == d]
    dd.calendario = f; ga.dd.calendario = f
    ga.gera_pacotes(dados)
    novo = txt(p).split("🔥", 1)[1].split("\n")[0].strip()
    if ant != novo:
        print("PRODUTO MUDOU", d, ant, novo)
        shutil.rmtree(p); shutil.copytree(bk, p); continue
    gerar_reels.gera(p)
    dst = os.path.join(DEST, nome(d))
    shutil.copytree(p, dst, dirs_exist_ok=True)
    t = txt(p)
    print(d, novo, "| preferida:", "Preferida" in t, "| sem gastar:", "sem gastar" in t)
dd.calendario = orig
