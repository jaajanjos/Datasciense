import sys, collections, json
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
from gerar_esboco_categorias import carrega_arvore, classifica, tags_do

arv = carrega_arvore()
it = g.itens(g.baixar_pagina(g.carregar_config()).conteudo)
grupos = collections.OrderedDict()
for c in arv["categorias"]:
    for s in c["subcategorias"]:
        grupos[(c["nome"], s["nome"])] = []
saida = []
for x in it:
    (c, s), t = classifica(x, arv), tags_do(x, arv)
    grupos[(c["nome"], s["nome"])].append((x["n"], x["nome"], t))
    saida.append({"n": x["n"], "nome": x["nome"], "cat": c["nome"], "sub": s["nome"], "tags": t})
json.dump(saida, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
cat = None
for (c, s), v in grupos.items():
    if c != cat:
        print(f"\n## {c} ({sum(len(w) for (cc, _), w in grupos.items() if cc == c)})"); cat = c
    print(f"  -- {s} ({len(v)})")
    for n, nome, t in v:
        print(f"     {n} {nome} {' '.join(t)}")
