import json, sys
f = sys.argv[1]
d = json.load(open(f, encoding="utf-8"))
metas = {
 "tecnologia-e-informatica": "Celulares, power bank e periféricos gamer com ótimo custo-benefício: veja as ofertas mais vendidas do Mercado Livre e compre com segurança.",
 "audio-e-tv": "Fones Bluetooth, caixas de som e Smart TVs com ótimo custo-benefício. Compare as melhores ofertas do Mercado Livre e escolha o ideal para sua casa.",
 "casa-e-eletrodomesticos": "Cozinha prática e casa limpa sem esforço: churrasqueira sem fumaça, cozedor de ovos, mop giratório e mais ofertas selecionadas no Mercado Livre.",
 "ferramentas-e-utilidades": "Lavadora de alta pressão Vonder, potes herméticos e porta-temperos: ferramentas e organização para a casa com as melhores ofertas do Mercado Livre.",
 "esporte-e-fitness": "Treine em casa e mantenha a suplementação em dia: creatina, halteres e barra fixa entre os mais vendidos do Mercado Livre. Veja as ofertas!",
 "beleza-e-perfumaria": "Perfumes e fragrâncias marcantes para presentear ou se presentear, com ofertas selecionadas no Mercado Livre. Confira!",
}
bf = "Black Friday 2026: Smart TVs, celulares, fone JBL, lavadora e churrasqueira elétrica selecionados no Mercado Livre. Confira as ofertas antes que acabem!"
for c in d["categorias"]:
    c["meta_descricao"] = metas[c["slug"]]
for t in d["tags"]:
    if t["tag"] == "black-friday":
        t["meta_descricao"] = bf
d["_leia_me"] += " 'meta_descricao' = descrição para o Google (All in One SEO), até ~155 caracteres."
json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
for k, v in list(metas.items()) + [("black-friday", bf)]:
    print(f"{len(v):>3}  {k}")
