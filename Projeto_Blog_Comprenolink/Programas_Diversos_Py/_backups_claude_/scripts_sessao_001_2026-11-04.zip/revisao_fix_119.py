import sys; sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
# (item, campo, texto antigo, texto novo) — tira menções a preço e "mais vendido" sem comprovação
R = [
 (3, "beneficios", "Excelente relação preço/qualidade", "Tamanho compacto de 32\""),
 (5, "desc", "O periférico mais vendido para quem busca", "Feito para quem busca"),
 (7, "selo", "Mais Vendido", "Câmera Tripla"),
 (7, "desc", "O smartphone mais vendido do marketplace, com", "Smartphone 5G com"),
 (7, "beneficios", "Preço competitivo", "Conexão 5G"),
 (8, "desc", " com preço agressivo.", "."),
 (8, "beneficios", "Preço agressivo, ótimo para primeiro celular", "Ótimo para o primeiro celular"),
 (15, "beneficios", "5 potes por um único preço", "5 potes no mesmo kit"),
 (36, "beneficios", "3 leggings por um único preço", "3 leggings no mesmo kit"),
 (41, "beneficios", "3 leggings por um único preço", "3 leggings no mesmo kit"),
 (53, "beneficios", "4 bermudas por um único preço", "4 bermudas no mesmo kit"),
 (61, "beneficios", "10 panos por um único preço", "10 panos no mesmo kit"),
 (112, "ideal", "Dia a dia", "Passeios"),
 (118, "ideal", "Uso diário", "Dia a dia na rua"),
]
cfg = g.carregar_config(); p = g.baixar_pagina(cfg)
it = {x["n"]: x for x in g.itens(p.conteudo)}
mud = {}
for n, k, a, b in R:
    v = mud.get(n, {}).get(k, it[n][k])
    if isinstance(v, list):
        assert a in v, (n, k, a); v = [b if i == a else i for i in v]
    else:
        assert v.count(a) == 1, (n, k, a); v = v.replace(a, b)
    mud.setdefault(n, {})[k] = v
s = p.conteudo
for n, c in mud.items():
    s, av = g.editar_item(s, n, c); assert not av, (n, av)
assert not g.verificar(s)
g.publicar(cfg, p, s, p.titulo)
dep = {x["n"]: x for x in g.itens(g.baixar_pagina(cfg).conteudo)}
print("aplicado:", all(dep[n][k] == v for n, c in mud.items() for k, v in c.items()),
      "| demais intactos:", all(dep[n] == it[n] for n in it if n not in mud), "| total:", len(dep))
