import sys; sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
cfg = g.carregar_config(); p = g.baixar_pagina(cfg)
it = {x["n"]: x for x in g.itens(p.conteudo)}
x = it[25]; assert x["nome"].startswith("Lavadora Vonder")
c = {"desc": x["desc"] + " Disponível em 127 V ou 220 V: escolha a voltagem na hora da compra.",
     "beneficios": [b if b != "Qualidade Vonder" else "127 V ou 220 V: você escolhe na compra" for b in x["beneficios"]]}
assert c["beneficios"] != x["beneficios"]
s, av = g.editar_item(p.conteudo, 25, c); assert not av, av
assert not g.verificar(s)
g.publicar(cfg, p, s, p.titulo)
d = {y["n"]: y for y in g.itens(g.baixar_pagina(cfg).conteudo)}
print("aplicado:", d[25]["desc"] == c["desc"] and d[25]["beneficios"] == c["beneficios"], "| demais intactos:", all(d[n] == it[n] for n in it if n != 25))
