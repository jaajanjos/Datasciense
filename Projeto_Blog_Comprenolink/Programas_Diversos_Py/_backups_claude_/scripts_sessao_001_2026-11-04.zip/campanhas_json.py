import json, shutil, sys, os
from datetime import datetime
f = sys.argv[1]
bk = os.path.join(os.path.dirname(f), "backups", f"categorias_{datetime.now():%Y-%m-%d_%Hh%M%S}.json")
shutil.copy2(f, bk); print("backup:", bk)
d = json.load(open(f, encoding="utf-8"))
tags = {t["tag"]: t for t in d["tags"]}
tags["black-friday"].update({
    "slug": "black-friday", "rotulo": "Black Friday", "emoji": "🔥",
    "intro": "Separamos as ofertas que mais valem a pena acompanhar na Black Friday 2026 (até 27/11/2026): Os produtos mais vendidos e bem avaliados do Mercado Livre. Clique em \"Ver preço\" para conferir o valor do dia no site oficial.",
    "campanha_ate": "2026-11-30",
    "faixa": "Black Friday 2026: veja a seleção de ofertas que valem a pena acompanhar",
    "botao": "Ver ofertas da Black Friday",
    "aviso_fim": "A Black Friday 2026 acabou, mas os produtos continuam à venda no Mercado Livre. Aproveite e veja também os presentes de Natal:",
    "destaques": ["smart tv samsung 55", "notebook asus", "caixa de som jbl boombox 4", "samsung galaxy a17", "air fryer",
                  "cama box baú", "lavadora vonder", "parafusadeira de impacto", "fone jbl tune", "smartwatch"],
})
tags["natal-presentes"].update({
    "slug": "presentes-de-natal", "rotulo": "Presentes de Natal", "emoji": "🎄",
    "titulo": "Presentes de Natal 2026: ideias que agradam",
    "intro": "Ideias de presentes de Natal para todos os gostos: perfumes, fones e caixas de som JBL, skincare, enxoval e decoração, selecionados entre os mais vendidos e bem avaliados do Mercado Livre. Clique em \"Ver preço\" para conferir o valor do dia no site oficial.",
    "meta_descricao": "Presentes de Natal 2026: perfumes árabes, JBL Go 5 e Boombox, kits de skincare, smartwatch, jogo de lençol e decoração natalina com ofertas do Mercado Livre.",
    "a_partir_de": "2026-12-01", "campanha_ate": "2026-12-25",
    "faixa": "Presentes de Natal 2026: ideias que agradam, separadas por categoria",
    "botao": "Ver presentes de Natal",
    "destaques": ["caixa de som jbl boombox 4", "perfume árabe sabah", "perfume árabe asad", "smartwatch", "fone jbl tune",
                  "caixa de som jbl go 5", "kit skincare vitamina c", "máquina de cortar", "jogo de lençol", "cortina de led"],
})
assert len(tags["natal-presentes"]["meta_descricao"]) <= 160, len(tags["natal-presentes"]["meta_descricao"])
json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("ok")
