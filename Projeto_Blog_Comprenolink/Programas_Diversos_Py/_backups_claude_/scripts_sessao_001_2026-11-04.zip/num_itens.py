import re, os, urllib.request


def mapa(h):
    return re.findall(r'<h2 id="item-(\d+)"[^>]*>(\d+)\.<a[^>]*>([^<]+)</a>', h)


B = r'D:\Mercado_Livre\9_Manutenção_Blog\2_DADOS\Blog_WordPress\backups'
chaves = ('Samsung 55', 'Boombox 4', 'Kit Skincare', 'Notebook ASUS', 'Smartwatch T900')
for f in ('pagina_2026-10-30_13h4319.html', 'pagina_2026-10-31_16h4022.html', 'pagina_2026-10-31_16h4136.html'):
    h = open(os.path.join(B, f), encoding='utf-8').read()
    m = mapa(h)
    print(f, len(m), [(a, b, n[:20]) for a, b, n in m if any(k in n for k in chaves)])
req = urllib.request.Request('https://comprenolink.net/melhores-produtos-mercado-livre-2026/?x=1', headers={'User-Agent': 'Mozilla/5.0'})
h = urllib.request.urlopen(req, timeout=60).read().decode('utf-8', 'ignore')
m = mapa(h)
print('SITE', len(m), [(a, b, n[:20]) for a, b, n in m if any(k in n for k in chaves)])
