import subprocess, os, time, shutil
from PIL import Image
S = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(S, "fotos_live"); os.makedirs(out, exist_ok=True)
C = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
dest = r"D:\mercado_livre\Manutenção_Blog\3_DOCUMENTACAO\Blog_WordPress\fotos_campanha_2026-10-26"; os.makedirs(dest, exist_ok=True)
for nome, path, alt in [("moda-infantil-e-juvenil", "moda-infantil-e-juvenil/", 3800), ("bebe-e-maternidade2", "bebe-e-maternidade/", 3000)]:
    png = os.path.join(out, nome + ".png")
    subprocess.run([C, "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--window-size=1280,{alt}",
                    "--user-data-dir=" + os.path.join(S, "chr2"), "--screenshot=" + png, f"https://comprenolink.net/{path.split('#')[0]}?v={int(time.time())}"],
                   capture_output=True, timeout=180)
    jpg = png[:-4] + ".jpg"; Image.open(png).convert("RGB").save(jpg, quality=80); shutil.copy2(jpg, dest); print(jpg)

