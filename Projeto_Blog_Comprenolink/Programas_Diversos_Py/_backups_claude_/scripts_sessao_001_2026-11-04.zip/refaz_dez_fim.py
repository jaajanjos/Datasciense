import sys, os, shutil
from datetime import date
FONTE = "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte"
sys.path.insert(0, FONTE); os.chdir(FONTE)
import dados_divulgacao as dd
import gerar_artes_catalogo as ga
import gerar_reels
BK = os.path.join(os.path.dirname(ga.PACOTE), "_backup_pacotes")
dados = dd.carrega_produtos()
itens = {x["n"]: x for x in dados["itens"]}
nat = list(dados["natal"])
nat = [x for x in nat if x["n"] != 51]
nat.insert(6, itens[51])
dados["natal"] = nat
orig = dd.calendario
DIAS = [date(2026,12,16), date(2026,12,18), date(2026,12,21), date(2026,12,23)]
nome = lambda d: f"{d:%Y-%m-%d}_{ga.DIAS[d.weekday()]}"
for d in DIAS:
    p = os.path.join(ga.PACOTE, nome(d))
    bk = os.path.join(BK, nome(d)+"_ANTES_pin")
    if not os.path.exists(bk): shutil.copytree(p, bk)
    f = lambda dados_, d=d: [l for l in orig(dados_) if l["data"] == d]
    dd.calendario = f; ga.dd.calendario = f
    ga.gera_pacotes(dados)
    gerar_reels.gera(p)
    print(d, open(os.path.join(p,"2_LEGENDA_REELS.txt"),encoding="utf-8-sig").read().splitlines()[2])
