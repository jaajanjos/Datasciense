import sys, types
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, "D:/mercado_livre/9_Manutenção_Blog/1_PROGRAMAS/Blog_WordPress")
import gerenciar_blog as g
APLICAR = "--aplicar" in sys.argv
ESPERADO = {
 180: "Tênis Bebê Menino Casual 2026", 177: "Tênis Bebê Menina Recém-Nascida Calce Fácil Rosa",
 175: "Sapatilha Bebê Mania Vermelha 31607", 174: "Tênis Bebê Mania Menina 71307",
 159: "Kit 6 Peças Bebê Canelado 3 Bodies e 3 Mijões RN", 158: "Conjunto Bebê Body Manga Longa e Calça Mijão",
 147: "Saco de Dormir Bebê Manta Soft e Sherpa Azul", 141: "Trocador de Fralda Portátil Coração Rosa",
 140: "Trocador de Fralda Dobrável Impermeável Nuvem Azul",
 136: "Kit 2 Óleo de Semente de Abóbora Zuchetti 240 Cápsulas", 132: "Licopeno 10 mg Recover Farma 30 Cápsulas",
 131: "Coenzima Q10 200 mg 60 Doses", 127: "Kit 3 Coenzima Q10 Ubiquinol 100 mg 60 Cápsulas",
 121: "Cúrcuma 130 mg + Colágeno Tipo II 45 mg 60 Cápsulas", 117: "Kit 2 Ômega 3 TG Vitamina Ifos 120 Cápsulas",
 116: "Ômega 3 EPA e DHA Vitafor 60 Cápsulas", 112: "Magnésio Dimalato 250 mg 120 Cápsulas",
}
cfg = g.carregar_config()
p = g.baixar_pagina(cfg, None)
s = p.conteudo
print("Itens na página antes:", len(g.secoes(s)))
falhas = []
for n in sorted(ESPERADO, reverse=True):
    x = g._sec(s, n)
    d = g.ler_item(s[x["ini"]:x["fim"]])
    ok = d["nome"].strip().lower().startswith(ESPERADO[n][:30].strip().lower())
    print(("OK   " if ok else "DIFERE"), n, "|", d["nome"][:70])
    if not ok:
        falhas.append(n)
if falhas:
    print("PARADO: nomes diferentes nos itens", falhas); sys.exit(2)
for n in sorted(ESPERADO, reverse=True):
    s, total = g.remover_item(s, n)
s, titulo = g.normalizar(s, p.titulo)
print("Itens depois:", len(g.secoes(s)), "| problemas:", g.verificar(s))
args = types.SimpleNamespace(aplicar=APLICAR, offline=None)
g.efetivar(cfg, args, p, s, titulo, False)
