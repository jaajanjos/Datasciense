import sys, types, re
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, "D:/mercado_livre/0- Pendencias/99_Programas_PY")
sys.path.insert(0, "D:/mercado_livre/9_Manutenção_Blog/1_PROGRAMAS/Blog_WordPress")
import textos_novos_anuncios_2026-10-30 as T
