import sys, os
from datetime import date
FONTE = "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte"
sys.path.insert(0, FONTE); os.chdir(FONTE)
import dados_divulgacao as dd
import gerar_artes_catalogo as ga
import gerar_reels
DIAS = {date(2026,11,25), date(2026,11,26), date(2026,11,28)}
dados = dd.carrega_produtos()
orig = dd.calendario
def so(d): return [l for l in orig(d) if l["data"] in DIAS]
dd.calendario = so; ga.dd.calendario = so
print(ga.gera_pacotes(dados))
for p in ("2026-11-25_qua","2026-11-26_qui","2026-11-28_sab"):
    print(gerar_reels.gera(os.path.join(ga.PACOTE, p)))
