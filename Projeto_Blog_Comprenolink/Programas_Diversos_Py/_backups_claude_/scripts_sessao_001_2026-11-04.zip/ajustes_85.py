import sys, os
sys.path.insert(0, sys.argv[1])
import gerenciar_blog as g
C = {
 64: ("Kit 4 Ursinhos", {"selo": "Natal Aconchegante"}),
 76: ("Jogo de Lençol", {"beneficios": ["Percal 600 fios egípcio", "4 peças: 2 lençóis + 2 fronhas", "Lençol de baixo com elástico", "Tamanho casal padrão"]}),
 77: ("Parafusadeira e Furadeira de Impacto Vonder", {"nome": "Parafusadeira de Impacto Vonder PFV120I"}),
 80: ("Parafusadeira de Impacto The Black Tools", {"nome": "Kit Parafusadeira The Black Tools 145 Peças", "selo": "2 Baterias Inclusas"}),
}
cfg = g.carregar_config(); p = g.baixar_pagina(cfg); antes = {x["n"]: x for x in g.itens(p.conteudo)}; s = p.conteudo
for n, (comeco, c) in C.items():
    assert antes[n]["nome"].startswith(comeco), (n, antes[n]["nome"])
    s, av = g.editar_item(s, n, c); assert not av, (n, av)
assert not g.verificar(s)
g.publicar(cfg, p, s, p.titulo)
d = {x["n"]: x for x in g.itens(g.baixar_pagina(cfg).conteudo)}
print("ajustes no ar:", all(all(d[n][k] == v for k, v in c.items()) for n, (_, c) in C.items()), "| outros intactos:", all(d[n] == antes[n] for n in antes if n not in C))
