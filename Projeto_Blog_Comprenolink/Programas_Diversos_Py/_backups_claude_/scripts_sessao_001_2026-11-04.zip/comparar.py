import sys, os, json
sys.stdout.reconfigure(encoding="utf-8")
P = r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress"
sys.path.insert(0, P)
import gerenciar_blog as g
ref = sys.argv[1]
antigo = open(ref, encoding="utf-8").read()
cfg = g.carregar_config()
p = g.baixar_pagina(cfg)
print("guia modificado em", p.modificado, "| titulo:", p.titulo)
A = {x["link"]: x for x in g.itens(antigo)}
N = g.itens(p.conteudo)
print("antes:", len(A), "agora:", len(N))
links_agora = {x["link"] for x in N}
for x in A.values():
    if x["link"] not in links_agora: print("REMOVIDO:", x["n"], x["nome"])
for x in N:
    a = A.get(x["link"])
    if not a:
        print(f"\n===== NOVO {x['n']}. {x['nome']}")
        for k, v in x.items():
            if k not in ("n", "nome"): print(f"  {k}: {v}")
    else:
        dif = {k: (a.get(k), v) for k, v in x.items() if k != "n" and a.get(k) != v}
        if dif:
            print(f"\n===== ALTERADO {x['n']} (antes {a['n']}). {x['nome']}")
            for k, (o, v) in dif.items(): print(f"  {k}:\n    antes: {o}\n    agora: {v}")
