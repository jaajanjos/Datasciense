import re, os, urllib.request, html


def mapa(h):
    return [(int(a), html.unescape(n).strip()) for a, b, n in re.findall(r'<h2 id="item-(\d+)"[^>]*>(\d+)\.<a[^>]*>([^<]+)</a>', h)]


B = r'D:\Mercado_Livre\9_Manutenção_Blog\2_DADOS\Blog_WordPress\backups\pagina_2026-10-31_16h4136.html'
ant = mapa(open(B, encoding='utf-8').read())
req = urllib.request.Request('https://comprenolink.net/melhores-produtos-mercado-livre-2026/?x=2', headers={'User-Agent': 'Mozilla/5.0'})
novo = mapa(urllib.request.urlopen(req, timeout=60).read().decode('utf-8', 'ignore'))
na, nn = {n for _, n in ant}, {n for _, n in novo}
print('SAIU do blog desde 31/10 16:41:')
for i, n in ant:
    if n not in nn:
        print('  item', i, n)
print('ENTROU no blog desde 31/10 16:41:')
for i, n in novo:
    if n not in na:
        print('  item', i, n)
print('contagens', len(ant), len(novo))
dif = [(i, a, b) for (i, a), (j, b) in zip(ant, novo) if a != b]
print('primeira diferenca de posicao:', dif[:2])
