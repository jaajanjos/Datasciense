import sys, os, shutil
from datetime import date
FONTE = "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte"
sys.path.insert(0, FONTE)
os.chdir(FONTE)
import dados_divulgacao as dd
import gerar_artes_catalogo as ga

DIA = date(2026, 12, 16)
pasta = os.path.join(ga.PACOTE, "2026-12-16_qua")
bk = pasta + "_BACKUP_kit_skincare_30out"
if not os.path.exists(bk):
    shutil.copytree(pasta, bk)

dados = dd.carrega_produtos()
dd.carrega_produtos.cache = dados
itens = {x["n"]: x for x in dados["itens"]}
nat = list(dados["natal"])
i111 = [k for k, x in enumerate(nat) if x["n"] == 111][0]
novo = itens[51]
nat = [x for x in nat if x["n"] != 51]
nat[i111] = novo
dados["natal"] = nat

orig = dd.calendario
def so_16(d):
    return [l for l in orig(d) if l["data"] == DIA]
dd.calendario = so_16
ga.dd.calendario = so_16
print(ga.gera_pacotes(dados))
import gerar_reels
print(gerar_reels.gera(pasta))
print(sorted(os.listdir(pasta)))
