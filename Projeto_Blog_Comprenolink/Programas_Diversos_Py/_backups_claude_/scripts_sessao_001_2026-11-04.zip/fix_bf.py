import sys, re
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
P = r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress"
# 1) gerador
f = P + r"\publicar_categorias.py"
t = open(f, encoding="utf-8").read()
velho = "{len(ys)} produtos entre os mais vendidos e bem avaliados do Mercado Livre. "
assert t.count(velho) == 1
t = t.replace(velho, "Os produtos mais vendidos e bem avaliados do Mercado Livre. ")
open(f, "w", encoding="utf-8", newline="").write(t)
f = P + r"\gerar_esboco_categorias.py"
t = open(f, encoding="utf-8").read()
velho = "{len(ys)} produtos escolhidos entre os mais vendidos"
assert t.count(velho) == 1
t = t.replace(velho, "os produtos mais vendidos")
open(f, "w", encoding="utf-8", newline="").write(t)
# 2) página no ar (id 116)
import gerenciar_blog as gb
from publicar_categorias import salva_backup
cfg = gb.carregar_config()
d = gb.requisitar(cfg, "GET", "/wp-json/wp/v2/pages/116?context=edit")
raw = d["content"]["raw"]
novo, n = re.subn(r"\): \d+ produtos entre os mais vendidos e bem avaliados", "): Os produtos mais vendidos e bem avaliados", raw)
assert n == 1, n
print("backup:", salva_backup("pagina116_black-friday", raw))
gb.requisitar(cfg, "POST", "/wp-json/wp/v2/pages/116", {"content": novo})
print("ok")
