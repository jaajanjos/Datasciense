T = {
 139: ("Coenzima Q10 200mg", dict(nome="Coenzima Q10 200 mg + Vitamina E 120 Cápsulas", selo="CoQ10 + Vitamina E",
   desc="Coenzima Q10 e vitamina E na mesma cápsula: CoQ10 na forma ubiquinona com 200 mg, em frasco com 120 cápsulas sem sabor.",
   beneficios=["200 mg de coenzima Q10 (ubiquinona)", "Com vitamina E", "Frasco com 120 cápsulas", "Sem sabor"],
   ideal=["Rotina de suplementação", "Quem quer frasco grande", "Complementar a alimentação", "Uso contínuo"],
   titulo_anuncio="Coenzima Q10 200 mg (Ubiquinona) + Vitamina E – 120 Cápsulas Sem Sabor")),
 140: ("Coenzima Q10 Ubiquinol Puro", dict(nome="Coenzima Q10 Ubiquinol Ecomev 120 Cápsulas", selo="Forma Ubiquinol",
   desc="Coenzima Q10 na forma ubiquinol: Ecomev com matéria-prima pura, em frasco com 120 cápsulas.",
   beneficios=["Coenzima Q10 na forma ubiquinol", "Matéria-prima pura", "Frasco com 120 cápsulas", "Marca Ecomev"],
   ideal=["Rotina de suplementação", "Quem prefere ubiquinol", "Complementar a alimentação", "Uso contínuo"],
   titulo_anuncio="Coenzima Q10 Ubiquinol Ecomev – 120 Cápsulas")),
}
