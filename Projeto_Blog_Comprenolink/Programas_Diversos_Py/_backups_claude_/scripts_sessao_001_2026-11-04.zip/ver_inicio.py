import sys; sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
from gerar_esboco_categorias import carrega_arvore, tags_do
cfg = g.carregar_config()
d = g.requisitar(cfg, "GET", "/wp-json/wp/v2/pages/14?context=edit")
open(sys.argv[1], "w", encoding="utf-8").write(d["content"]["raw"])
arv = carrega_arvore()
for t in ("black-friday", "natal-presentes"):
    xs = [x for x in g.itens(g.baixar_pagina(cfg).conteudo) if t in tags_do(x, arv)]
    print("==", t, len(xs))
    for x in xs: print("  ", x["n"], x["nome"], "|", x["selo"])
