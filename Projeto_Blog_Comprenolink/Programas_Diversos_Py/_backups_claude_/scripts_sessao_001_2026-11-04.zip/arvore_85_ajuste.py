import json, sys
f = sys.argv[1]
d = json.load(open(f, encoding="utf-8"))
cat = {c["slug"]: c for c in d["categorias"]}
# Smart TVs antes de Fones & Caixas (combo TV + soundbar é TV)
subs = cat["audio-e-tv"]["subcategorias"]
tv = next(s for s in subs if s["nome"] == "Smart TVs"); subs.remove(tv); subs.insert(0, tv)
# caixa de som de PC é periférico
per = next(s for s in cat["tecnologia-e-informatica"]["subcategorias"] if s["nome"] == "Periféricos")
per["palavras"].append("caixa de som para pc")
# Black Friday: só a cama box baú (não a saia)
bf = next(t for t in d["tags"] if t["tag"] == "black-friday")
bf["palavras"] = ["cama box baú" if p == "cama box" else p for p in bf["palavras"]]
json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("ok")
