import shutil
from datetime import datetime, timedelta

UTC = timedelta(hours=3)
EV = [
    ("2026-10-29 10:00", 30, "Reconectar o Chrome e agendar posts do Instagram",
     "1) Abrir o Google Chrome (NÃO o Edge).\n2) Clicar no ícone Claude (estrelinha laranja) e entrar com a mesma conta do app.\n"
     "3) Escrever ao Claude: reconectei.\n4) Aprovar a amostra do dia 02/11 – o Claude agenda os posts e Reels dos 27 dias.\n"
     "Passo a passo: D:\\mercado_livre\\Guia_Passo_a_Passo_Instagram_2026.pdf (seção 2)."),
    ("2026-10-30 19:00", 15, "Testar a automação BLACK do ManyChat",
     "Com o Instagram PESSOAL (ou do sócio), comentar BLACK no post fixado do @compre.no.link e ver se chega a mensagem no Direct.\n"
     "Se não chegar: compre.no.link > Configurações > Mensagens e respostas a stories > Ferramentas conectadas > Permitir acesso às mensagens.\n"
     "Guia: seção 3."),
    ("2026-10-31 10:00", 30, "WhatsApp Business: catálogo e Canal",
     "1) Cadastrar 2 itens no catálogo: CAT-bebe-e-maternidade e CAT-moda-infantil-e-juvenil (pasta 06_CATALOGO_WHATSAPP\\CATEGORIAS).\n"
     "2) Criar o Canal do WhatsApp e mandar o link ao Claude."),
    ("2026-11-05 10:00", 60, "Reunião com o sócio: Turbinar e análise crítica",
     "Levar: Plano_Turbinar_Instagram_2026.pdf (aprovação na última página) e Analise_Critica_Anuncios_2026-10-27.pdf.\n"
     "Decidir: valor máximo do Turbinar, quem paga, retirar ou não os 17 anúncios repetidos (seção 6.1).\n"
     "Ler antes os termos do ML Afiliados sobre anúncio pago."),
]
f = lambda d: (d + UTC).strftime("%Y%m%dT%H%M%SZ")
L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//comprenolink//Pendencias//PT-BR", "X-WR-CALNAME:Pendências comprenolink"]
for i, (q, mins, tit, desc) in enumerate(EV):
    d = datetime.strptime(q, "%Y-%m-%d %H:%M")
    esc = lambda t: t.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    L += ["BEGIN:VEVENT", f"UID:pend-{d:%Y%m%d%H%M}-{i}@comprenolink.net", f"DTSTAMP:{f(datetime.now())}",
          f"DTSTART:{f(d)}", f"DTEND:{f(d + timedelta(minutes=mins))}", f"SUMMARY:{esc(tit)}", f"DESCRIPTION:{esc(desc)}",
          "BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{esc(tit)}", "TRIGGER:-PT30M", "END:VALARM", "END:VEVENT"]
L.append("END:VCALENDAR")
saida = r"D:\mercado_livre\Agenda_Pendencias_29out_a_05nov.ics"
open(saida, "w", encoding="utf-8", newline="\r\n").write("\n".join(L) + "\n")
for destino in (r"E:\OneDrive\Download", r"D:\mercado_livre\4- Celular_Whatsapp"):
    shutil.copy2(saida, destino)
print(len(EV), "eventos ->", saida)
