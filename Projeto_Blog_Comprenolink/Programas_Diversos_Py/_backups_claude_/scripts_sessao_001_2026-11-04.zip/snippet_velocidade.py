import sys, json, os
from datetime import datetime
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g

cfg = g.carregar_config()
# backup da lista de snippets antes de mexer
todos = g.requisitar(cfg, "GET", "/wp-json/code-snippets/v1/snippets")
bk = os.path.join(r"D:\mercado_livre\Manutenção_Blog\2_DADOS\Blog_WordPress\backups",
                  f"snippets_{datetime.now():%Y-%m-%d_%Hh%M%S}.json")
json.dump(todos, open(bk, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("backup:", bk, "|", len(todos), "snippets")
if any(s.get("name") == "Velocidade: fotos sob demanda e sem emojis" for s in todos):
    sys.exit("já existe – nada feito")

codigo = r"""// Velocidade do blog (28/10/2026). As fotos dos cartões vêm do Mercado Livre sem largura/altura, então o WordPress
// não aplica o carregamento sob demanda sozinho: aqui as 3 primeiras carregam na hora e as demais só quando chegam perto da tela.
add_filter('the_content', function ($html) {
    if (is_admin() || !is_singular()) return $html;
    $n = 0;
    return preg_replace_callback('/<img\b(?![^>]*\bloading=)[^>]*>/i', function ($m) use (&$n) {
        $n++;
        return $n <= 3 ? $m[0] : preg_replace('/^<img\b/i', '<img loading="lazy"', $m[0]);
    }, $html);
}, 20);

// Emojis do WordPress: 10 arquivos a menos por página (o navegador já mostra emojis sozinho).
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
add_filter('emoji_svg_url', '__return_false');"""
r = g.requisitar(cfg, "POST", "/wp-json/code-snippets/v1/snippets",
                 {"name": "Velocidade: fotos sob demanda e sem emojis", "code": codigo, "scope": "front-end", "active": True,
                  "desc": "Lazy load das fotos dos cartões (exceto as 3 primeiras) e remove scripts de emoji. Criado em 28/10/2026."})
print(r.get("id"), r.get("name"), "ativo:", r.get("active"), "erro:", r.get("code_error"))
