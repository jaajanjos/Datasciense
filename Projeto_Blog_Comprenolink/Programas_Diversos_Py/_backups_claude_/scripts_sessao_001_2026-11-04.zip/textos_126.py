T = {
 126: ("Suplemento Ômega 3 Epa Dha", dict(nome="Ômega 3 EPA e DHA Vitafor 60 Cápsulas", selo="Marca Vitafor",
   desc="Ômega 3 para complementar a alimentação na correria do dia a dia: suplemento Vitafor com EPA e DHA, em frasco com 60 cápsulas.",
   beneficios=["Ômega 3 com EPA e DHA", "Frasco com 60 cápsulas", "Marca Vitafor", "Prático para a rotina"],
   ideal=["Complementar a alimentação", "Rotina corrida", "Rotina de suplementação", "Uso contínuo"],
   titulo_anuncio="Ômega 3 EPA e DHA Vitafor – 60 Cápsulas")),
}
