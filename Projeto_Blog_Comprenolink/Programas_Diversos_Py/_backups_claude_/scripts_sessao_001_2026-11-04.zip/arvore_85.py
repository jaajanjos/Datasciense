import json, sys
f = sys.argv[1]
d = json.load(open(f, encoding="utf-8"))
cat = {c["slug"]: c for c in d["categorias"]}
sub = lambda slug, nome: next(s for s in cat[slug]["subcategorias"] if s["nome"] == nome)
def add(slug, nome, *pal):
    s = sub(slug, nome)
    s["palavras"] += [p for p in pal if p not in s["palavras"]]

# Áudio & TV: caixas amplificadas/soundbar e nova subcategoria Projeção
add("audio-e-tv", "Fones & Caixas de Som", "caixa amplificada")
cat["audio-e-tv"]["subcategorias"].append({"nome": "Projeção", "palavras": ["tela de projeção", "projetor"]})
cat["audio-e-tv"]["intro"] = "Som e imagem de qualidade para a sua casa: fones, caixas de som, soundbars, Smart TVs e telas de projeção com melhor custo-benefício do Mercado Livre."
cat["audio-e-tv"]["meta_descricao"] = "JBL Boombox, caixa amplificada, soundbar, Smart TV MiniLED e tela de projeção: som e imagem com ótimo custo-benefício nas ofertas do Mercado Livre."
# Casa & Eletrodomésticos: mesa e panos entram em Utensílios
s = sub("casa-e-eletrodomesticos", "Utensílios de Cozinha"); s["nome"] = "Utensílios, Cozinha & Mesa"
s["palavras"] += ["taça", "pano de prato", "panos de prato"]
# Casa, Cama & Decoração: enxoval e Natal
add("casa-cama-e-decoracao", "Cama & Descanso", "lençol", "fronha", "colcha", "cobre-leito", "saia para cama", "cabeceira")
add("casa-cama-e-decoracao", "Decoração & Iluminação", "ursinho", "natalino", "enfeite")
cat["casa-cama-e-decoracao"]["intro"] = "Conforto e estilo para todos os cantos da casa: enxoval de cama, cabeceiras, redes, espelhos e decoração de Natal com as melhores ofertas do Mercado Livre."
cat["casa-cama-e-decoracao"]["meta_descricao"] = "Jogo de lençol 600 fios, colcha, fronha de cetim, cabeceira adesiva, cama box e decoração de Natal: conforto e estilo com ofertas do Mercado Livre."
# Ferramentas & Utilidades: manuais e arara
s = sub("ferramentas-e-utilidades", "Ferramentas Elétricas")
idx = cat["ferramentas-e-utilidades"]["subcategorias"].index(s)
cat["ferramentas-e-utilidades"]["subcategorias"].insert(idx + 1, {"nome": "Ferramentas Manuais", "palavras": ["chave catraca", "chave", "caixa de ferramentas", "alicate", "martelo"]})
add("ferramentas-e-utilidades", "Organização", "arara")
cat["ferramentas-e-utilidades"]["meta_descricao"] = "Parafusadeira de impacto, catraca, caixa de ferramentas, lavadora Vonder, mop e organizadores: ferramentas e utilidades com as melhores ofertas do Mercado Livre."
# Beleza & Saúde: vitaminas e colágeno (depois de Skincare, que pega o Kit Kokeshi)
b = cat["beleza-e-saude"]["subcategorias"]
sk = next(x for x in b if x["nome"] == "Skincare")
sk["palavras"] = [p for p in sk["palavras"] if p != "colágeno"]
b.insert(b.index(sk) + 1, {"nome": "Vitaminas & Colágeno", "palavras": ["colágeno", "vitamina b12", "vitamina d", "multivitamínico", "ômega"]})
cat["beleza-e-saude"]["intro"] = "Perfumes marcantes, skincare, colágeno e vitaminas, cuidados pessoais e saúde no dia a dia, com ofertas selecionadas no Mercado Livre."
cat["beleza-e-saude"]["meta_descricao"] = "Perfumes árabes, sérum de vitamina C, colágeno Verisol, vitamina B12 e skincare: beleza e cuidado no dia a dia com as melhores ofertas do Mercado Livre."
# Tags
tags = {t["tag"]: t for t in d["tags"]}
tags["black-friday"]["palavras"] += ["miniled", "boombox", "parafusadeira", "caixa amplificada"]
tags["natal-presentes"]["palavras"] += ["ursinho", "taças", "boombox", "jogo de lençol", "fronhas de cetim", "sérum"]
tags["verao"]["palavras"] += ["caixa amplificada", "boombox"]
tags["apartamento"]["palavras"] += ["arara", "cabeceira"]
json.dump(d, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("ok")
