import uuid
from datetime import datetime

ARQ = r"D:\mercado_livre\Manutenção_Blog\3_DOCUMENTACAO\LEMBRETE_SEMANAL_GERAR_CATEGORIAS.ics"
LINK = "https://comprenolink.net/black-friday/"
NATAL = "https://comprenolink.net/presentes-de-natal/"
# (data AAAAMMDD, hora HHMM, minutos, título, descrição, regra de repetição)
E = [
 ("20261102", "1000", 10, "Blog: cadastrou anúncios? Pedir 'gerar as categorias'",
  "Se cadastrou anúncios na semana: pedir ao Claude 'gerar as categorias' para os textos de venda. Os anúncios já entram sozinhos nas páginas a cada 3 horas; o Claude faz nome curto, selo, descrição e listas no tom de venda, sem preço e sem promessas.", "FREQ=WEEKLY;BYDAY=MO"),
]
agora = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//comprenolink//agenda blog//PT", "CALSCALE:GREGORIAN",
     "BEGIN:VTIMEZONE", "TZID:America/Sao_Paulo", "BEGIN:STANDARD", "DTSTART:19700101T000000",
     "TZOFFSETFROM:-0300", "TZOFFSETTO:-0300", "TZNAME:-03", "END:STANDARD", "END:VTIMEZONE"]
esc = lambda t: t.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
for d, h, m, tit, desc, rr in E:
    hh, mm = int(h[:2]), int(h[2:]) + m
    fim = f"{d}T{hh + mm // 60:02d}{mm % 60:02d}00"
    L += ["BEGIN:VEVENT", f"UID:{uuid.uuid4()}@comprenolink", f"DTSTAMP:{agora}",
          f"DTSTART;TZID=America/Sao_Paulo:{d}T{h}00", f"DTEND;TZID=America/Sao_Paulo:{fim}",
          f"SUMMARY:{esc(tit)}", f"DESCRIPTION:{esc(desc)}"]
    if rr:
        L.append(f"RRULE:{rr}")
    L += ["BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{esc(tit)}", "TRIGGER:-PT30M", "END:VALARM", "END:VEVENT"]
L.append("END:VCALENDAR")
with open(ARQ, "w", encoding="utf-8", newline="\r\n") as f:
    f.write("\n".join(L) + "\n")
print(ARQ, len(E), "eventos")
