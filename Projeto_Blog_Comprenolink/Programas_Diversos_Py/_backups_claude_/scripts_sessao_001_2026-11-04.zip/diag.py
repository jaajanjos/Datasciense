import sys, base64, urllib.request, urllib.error, time
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, sys.argv[1])
import gerenciar_blog as g
cfg = g.carregar_config()
u, s = cfg["usuario"], cfg["senha_aplicativo"]
print("usuario:", u, "| senha: %d caracteres, espacos=%d" % (len(s), s.count(" ")))
tok = base64.b64encode(f"{u}:{s}".encode()).decode()
def req(path, hdr):
    url = cfg["site"] + path + ("&" if "?" in path else "?") + "nocache=%d" % time.time()
    r = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "diag", **hdr})
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            return resp.status, resp.read().decode()[:160], dict(resp.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:200], dict(e.headers)
for nome, h in [("so Authorization", {"Authorization": "Basic " + tok}),
                ("so X-WP-Auth", {"X-WP-Auth": "Basic " + tok}),
                ("ambos", {"Authorization": "Basic " + tok, "X-WP-Auth": "Basic " + tok}),
                ("sem login", {})]:
    st, body, hd = req("/wp-json/wp/v2/users/me?context=edit", h)
    print(f"[{nome}] {st} {body[:140]}")
    print("   ", {k: v for k, v in hd.items() if k.lower() in ("x-litespeed-cache", "x-hcdn-cache-status", "cache-control", "server", "x-painel-diag")})
