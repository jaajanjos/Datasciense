import json, shutil, os
import openpyxl
S = r"C:\Users\SVR_RYZEN_JAA\AppData\Local\Temp\claude\C--Users-SVR-RYZEN-JAA\d759a442-1d58-4e20-94e0-f2e7cc22f60c\scratchpad\links_cnl.json"
dados = json.load(open(S, encoding="utf-8"))
PASTA = "D:/mercado_livre/0- Pendencias/1_Pendencias/"
txt = PASTA + "Links_catalogo_por_produto_CORRIGIDOS_2026-11-01.txt"
linhas = ["LINKS CORRIGIDOS DO CATÁLOGO POR PRODUTO (WhatsApp Business) – 01/11/2026",
          "Como usar: WhatsApp Business > Catálogo > toque no item > Editar > campo Link > apague o link e cole o link abaixo > Salvar.",
          "Só os 10 itens marcados TROCAR precisam de ajuste. Os marcados OK já estão certos. O CNL-111 não existe mais (apague do catálogo).",
          "O número depois de #item- mudou porque o blog retirou um produto em 31/10.", ""]
for d in dados:
    if d["acao"] == "TROCAR":
        linhas += [f"{d['cod']} – {d['nome']}", f"TROCAR  (#item-{d['velho']} -> #item-{d['novo']})", d["link"], ""]
for d in dados:
    if d["acao"] == "OK":
        linhas += [f"{d['cod']} – {d['nome']}  -> OK, nada a fazer"]
linhas += ["", "CNL-111 – Kit Skincare Vitamina C Dermachem 5 Itens  -> APAGAR do catálogo (produto saiu do Mercado Livre)"]
open(txt, "w", encoding="utf-8").write("\n".join(linhas) + "\n")
print("txt:", txt)

xl = r"D:\Mercado_Livre\4- Celular_Whatsapp\06_CATALOGO_WHATSAPP\CATALOGO_WHATSAPP.xlsx"
bk = r"D:\mercado_livre\0- Pendencias\99_Programas_PY\_backups_claude_30out\CATALOGO_WHATSAPP_antes_links_01nov.xlsx"
shutil.copy2(xl, bk)
wb = openpyxl.load_workbook(xl)
ws = wb.active
novo = {d["cod"]: d["link"] for d in dados if d["acao"] == "TROCAR"}
n = 0
for r in ws.iter_rows(min_row=2):
    if r[0].value in novo:
        r[4].value = novo[r[0].value]
        n += 1
wb.save(xl)
print("planilha atualizada, links trocados:", n)
