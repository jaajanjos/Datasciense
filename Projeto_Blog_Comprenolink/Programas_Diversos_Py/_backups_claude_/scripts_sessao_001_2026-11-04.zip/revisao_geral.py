import sys, os, re, json, html
sys.path.insert(0, sys.argv[1])
import gerenciar_blog as g

# Correções da revisão geral (só fatos dos anúncios / cartões do Mercado Livre)
C = {
 1: ("Fone In-Ear QCY", dict(beneficios=["Cancelamento de ruído (ANC)", "Estojo de carregamento portátil", "Resistência à água e suor", "Ótimo para treino e dia a dia"],
                              ideal=["Música", "Treino", "Jogos", "Chamadas"])),
 2: ("Caixa de Som Bluetooth", dict(nome="Caixa de Som Aiwa Boombox Plus 200 W", selo="Preferida para Uso Externo",
        beneficios=["200 W de potência", "Até 30 h de bateria", "Resistente à água e poeira (IP66)", "Bluetooth e entrada USB"])),
 4: ("Smart TV LG", dict(nome='Smart TV LG 32" webOS',
        beneficios=["Qualidade de imagem com HDR10", "webOS com vasto catálogo de apps", "Processador com recursos de IA", "Wi-Fi e Bluetooth"])),
 5: ("Mouse Gamer Sem Fio", dict(beneficios=["Sensor de alta precisão (DPI ajustável)", "Sem fios, total liberdade", "Bateria recarregável", "3 modos de conexão"],
                                  ideal=["Jogos competitivos", "Trabalho", "Design gráfico", "Estudos"])),
 7: ("Samsung Galaxy A17", dict(nome="Samsung Galaxy A17 5G 128GB", ideal=["Estudantes", "Redes sociais", "Fotos", "Trabalho"])),
 9: ("Power Bank Anker", dict(nome="Power Bank Anker 25.000 mAh 165 W",
        beneficios=["25.000 mAh com carga turbo de 165 W", "4 portas e 2 cabos USB-C integrados", "Tela digital que mostra a carga", "Carrega até notebook"],
        ideal=["Viagem", "Trabalho", "Emergências", "Carro"])),
 12: ("Copo Térmico", dict(titulo_anuncio="Copo Térmico Inox 1,2 L com Tampa e Canudo – Isolamento a Vácuo")),
 13: ("Fone JBL Tune 730", dict(ideal=["Música", "Filmes e séries", "Chamadas e reuniões", "Viagens"])),
 14: ("Motorola Moto G24", dict(ideal=["Quem precisa de muito espaço", "Fotos e redes sociais", "Estudantes", "Melhor custo-benefício"])),
 15: ("Kit 5 Potes", dict(titulo_anuncio="Kit 5 Potes Herméticos Aero Home – Freezer e Micro-ondas")),
 18: ("Creatina Dux", dict(ideal=["Quem treina musculação", "Pós-treino", "Misturar em sucos e vitaminas", "Quem prefere creatina pura"])),
 24: ("Perfume Árabe Sabah", dict(ideal=["Ocasiões especiais", "Encontros e festas", "Presente para ela", "Presente de aniversário"])),
 25: ("Lavadora de Alta Pressão", dict(nome="Lavadora Vonder LAV 1300 – 90 bar")),
 29: ("Churrasqueira Elétrica", dict(nome="Churrasqueira Elétrica Sem Fumaça Aero Home")),
}
# Título do cartão dos produtos do plugin Hostinger (vem do JSON do bloco)
TIT_PLUGIN = {
 2: "Caixa de Som Aiwa Boombox Plus 200 W – Bluetooth, 30 h, IP66",
 4: 'Smart TV LG 32" LB650 webOS – HDR10, Wi-Fi e Bluetooth',
 5: "Mouse Gamer Sem Fio Attack Shark R1 – 3 Modos de Conexão",
 7: "Smartphone Samsung Galaxy A17 5G 128 GB – Cinza",
 9: "Power Bank Anker 25.000 mAh 165 W – 4 Portas e 2 Cabos USB-C",
 10: "Headset Gamer Havit H2002d – PS4, PS5, Xbox e PC",
}

cfg = g.carregar_config()
p = g.baixar_pagina(cfg)
print("página lida, modificada em", p.modificado)
antes = {x["n"]: x for x in g.itens(p.conteudo)}
s = p.conteudo
for n, (comeco, c) in C.items():
    assert antes[n]["nome"].startswith(comeco), f"item {n} mudou: {antes[n]['nome']}"
    s, av = g.editar_item(s, n, c)
    assert not av, (n, av)
for n, tit in TIT_PLUGIN.items():
    x = g._sec(s, n); t = s[x["ini"]:x["fim"]]
    m = re.search(r'(<!--\s*wp:hostinger-affiliate-plugin/[\w-]+\s+)(\{.*?\})(\s*/?-->)', t, re.S)
    assert m, f"item {n} sem bloco do plugin"
    attrs = json.loads(m.group(2))
    for prod in (attrs.get("items") or {}).values():
        prod["title"] = tit
    novo_json = json.dumps(attrs, ensure_ascii=False, separators=(",", ":")).replace("--", "\\u002d\\u002d")
    t2 = t[:m.start(2)] + novo_json + t[m.end(2):]
    t2, _ = re.subn(r'(<img\b[^>]*\balt=")[^"]*(")', lambda k: k.group(1) + html.escape(tit) + k.group(2), t2, count=1)
    s = s[:x["ini"]] + t2 + s[x["fim"]:]
assert not g.verificar(s), g.verificar(s)
g.publicar(cfg, p, s, p.titulo)
depois = {x["n"]: x for x in g.itens(g.baixar_pagina(cfg).conteudo)}
ok = all(all(depois[n][k] == v for k, v in c.items()) for n, (_, c) in C.items())
ok_tit = all(depois[n]["titulo_anuncio"] == t for n, t in TIT_PLUGIN.items())
links = all(depois[n]["link"] == antes[n]["link"] for n in antes)
intactos = all(depois[n] == antes[n] for n in antes if n not in C and n not in TIT_PLUGIN)
print("correções no ar:", ok, "| títulos do plugin:", ok_tit, "| links iguais:", links, "| demais itens intactos:", intactos, "| total:", len(depois))
