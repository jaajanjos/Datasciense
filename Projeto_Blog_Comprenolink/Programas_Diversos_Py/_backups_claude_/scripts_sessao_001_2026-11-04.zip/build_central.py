import subprocess, os, tempfile
W = r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress"
R = r"D:\mercado_livre\Manutenção_Blog"
t = os.path.join(tempfile.gettempdir(), "pyi_build_central")
r = subprocess.run(["python", "-m", "PyInstaller", "--onefile", "--windowed", "--noconfirm", "--clean", "--name", "CentralBlog",
    "--paths", os.path.join(W, ".."), "--paths", W, "--distpath", R, "--workpath", t, "--specpath", t, os.path.join(W, "..", "central_blog.py")],
    capture_output=True, text=True, encoding="utf-8", errors="replace")
print(r.returncode, r.stderr[-400:])
