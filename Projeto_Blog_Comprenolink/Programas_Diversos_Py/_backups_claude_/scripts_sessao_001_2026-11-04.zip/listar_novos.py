import sys
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g

ini = int(sys.argv[1]) if len(sys.argv) > 1 else 161
p = g.baixar_pagina(g.carregar_config())
for x in g.itens(p.conteudo):
    if x["n"] < ini:
        continue
    print(f"#{x['n']} {x['nome']} | selo: {x['selo']} | desc: {x['desc'][:300]} | "
          f"ben: {' / '.join(b[:220] for b in x['beneficios'])} | ideal: {' / '.join(x['ideal'])}")
