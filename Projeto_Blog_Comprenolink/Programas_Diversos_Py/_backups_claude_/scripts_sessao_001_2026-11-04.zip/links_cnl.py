import re, sys, json
sys.path.insert(0, "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte")
import openpyxl
import dados_divulgacao as dd

def norm(t):
    t = (t or "").replace("″", '"').replace("×", "x").replace("’", "'").replace("–", "-").replace("\u00a0", " ")
    return re.sub(r"\s+", " ", t).strip().lower()

itens = dd.carrega_produtos()["itens"]
ws = openpyxl.load_workbook(r"D:\Mercado_Livre\4- Celular_Whatsapp\06_CATALOGO_WHATSAPP\CATALOGO_WHATSAPP.xlsx").active
saida = []
for r in ws.iter_rows(min_row=2, values_only=True):
    if not r[0]:
        continue
    cod, nome, link = r[0], r[1], r[4]
    m = re.search(r"#item-(\d+)", link)
    velho = int(m.group(1))
    ach = [x for x in itens if norm(x["nome"])[:28] == norm(nome)[:28]]
    if not ach:
        saida.append(dict(cod=cod, nome=nome, acao="APAGAR"))
        continue
    novo = ach[0]["n"]
    saida.append(dict(cod=cod, nome=nome, velho=velho, novo=novo, link=re.sub(r"#item-\d+", f"#item-{novo}", link), acao="OK" if novo == velho else "TROCAR"))
json.dump(saida, open(r"C:\Users\SVR_RYZEN_JAA\AppData\Local\Temp\claude\C--Users-SVR-RYZEN-JAA\d759a442-1d58-4e20-94e0-f2e7cc22f60c\scratchpad\links_cnl.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for s in saida:
    print(s["cod"], s["acao"], s.get("velho"), s.get("novo"), s["nome"][:36])
print("exemplo:", next(s["link"] for s in saida if s["acao"] == "TROCAR"))
