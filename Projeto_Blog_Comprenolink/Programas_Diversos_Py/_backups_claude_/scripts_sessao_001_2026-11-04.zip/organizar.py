import os, shutil, sys
sys.stdout.reconfigure(encoding="utf-8")
R = r"D:\$RECYCLE.BIN\S-1-5-21-2801237355-384531268-2296058409-1003"
M = "D:\mercado_livre\Manuten\u00e7\u00e3o_Blog"
BM = r"D:\mercado_livre\Blog_Maquinas_Manutencao"
assert not os.listdir(M), "pasta destino nao esta vazia"
P_WP = os.path.join(M, "1_PROGRAMAS", "Blog_WordPress")
P_MQ = os.path.join(M, "1_PROGRAMAS", "Blog_Maquinas")
D_WP = os.path.join(M, "2_DADOS", "Blog_WordPress")
D_MQ = os.path.join(M, "2_DADOS", "Blog_Maquinas")
DOC_WP = os.path.join(M, "3_DOCUMENTACAO", "Blog_WordPress")
DOC_MQ = os.path.join(M, "3_DOCUMENTACAO", "Blog_Maquinas")
PAC = os.path.join(M, "4_PACOTE_OUTRO_PC")
ORIG = os.path.join(M, "9_ORIGINAIS_NAO_MEXER", "Blog_Maquinas_gerador_antigo")
for d in (P_WP, P_MQ, os.path.join(D_WP, "backups"), os.path.join(D_WP, "treino"), D_MQ, DOC_WP, DOC_MQ, PAC, ORIG):
    os.makedirs(d, exist_ok=True)
def cp(src, dst):
    s = os.path.join(R, src) if not os.path.isabs(src) else src
    if os.path.isdir(s): shutil.copytree(s, dst, dirs_exist_ok=True)
    else: shutil.copy2(s, dst)
    print("ok", os.path.relpath(dst, M))
# Programas WordPress (versao mais recente, 13h52)
cp("$RBS4H71.py", os.path.join(P_WP, "gerenciar_blog.py"))
cp("$RCCZCJF.py", os.path.join(P_WP, "painel_blog.py"))
cp("$R0GKU8O.py", os.path.join(P_WP, "gerar_manual_pdf.py"))
cp("$R4POHEF.py", os.path.join(P_WP, "gerar_manual_treino.py"))
# Dados WordPress
cp("$RWTZMSM.json", os.path.join(D_WP, "wp_credenciais.json"))
cp("$RK4B4T3.json", os.path.join(D_WP, "wp_credenciais.exemplo.json"))
cp(os.path.join(R, "$RJB6BAJ", "pagina_exemplo.html"), os.path.join(D_WP, "treino", "pagina_exemplo.html"))
# Documentacao WordPress
cp("$RO3WP1C.txt", os.path.join(DOC_WP, "LEIA-ME_painel_wordpress.txt"))
cp("$RHDRDMQ.pdf", os.path.join(DOC_WP, "Manual_Manutencao_Blog.pdf"))
cp("$RSTAX9M.pdf", os.path.join(DOC_WP, "Manual_Treino.pdf"))
cp("$RX6ZQHW.php", os.path.join(DOC_WP, "2_snippet_login_painel.php"))
# Pacote outro PC (exe guardam dados ao lado do proprio exe)
cp("$RO7PTTC", PAC)
# Blog das maquinas (criado hoje)
cp(os.path.join(BM, "1_PAINEL", "painel-manutencao-anuncios.html"), os.path.join(P_MQ, "painel-manutencao-anuncios.html"))
cp(os.path.join(BM, "1_PAINEL", "painel-manutencao-anuncios.html"), os.path.join(PAC, "painel-manutencao-anuncios.html"))
cp(os.path.join(BM, "3_DOCUMENTACAO", "GUIA_PASSO_A_PASSO.txt"), os.path.join(DOC_MQ, "GUIA_PASSO_A_PASSO.txt"))
cp(os.path.join(BM, "3_DOCUMENTACAO", "imagem_do_painel.png"), os.path.join(DOC_MQ, "imagem_do_painel.png"))
cp(os.path.join(BM, "9_ORIGINAIS_NAO_MEXER"), ORIG)
