"""Árvore para os itens 161-200: subcategorias de roupinhas e sapatinhos em Bebê & Maternidade e categoria nova
Moda Infantil & Juvenil (logo depois de Bebê, antes de Casa/Cama e Esporte, que têm "manta", "legging", "top").
Mostra quem mudou de categoria entre os itens 1-160 (não deve mudar ninguém) e quem ficou sem categoria."""
import json, os, shutil, sys
from datetime import datetime
sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as g
import gerar_esboco_categorias as ge

F = r"D:\mercado_livre\Manutenção_Blog\2_DADOS\Blog_WordPress\categorias.json"
it = g.itens(g.baixar_pagina(g.carregar_config()).conteudo)


def mapa():
    arv = ge.carrega_arvore()
    return {x["n"]: tuple(v and v["nome"] for v in ge.classifica(x, arv)) for x in it}


antes = mapa()
if "--aplicar" in sys.argv:
    bk = os.path.join(os.path.dirname(F), "backups", f"categorias_{datetime.now():%Y-%m-%d_%Hh%M%S}.json")
    shutil.copy2(F, bk); print("backup:", bk)
    d = json.load(open(F, encoding="utf-8"))
    cats = d["categorias"]
    bebe = next(c for c in cats if c["slug"] == "bebe-e-maternidade")
    nomes = [s["nome"] for s in bebe["subcategorias"]]
    if "Sapatinhos" not in nomes:
        k = nomes.index("Naninhas & Móbiles")  # antes de Naninhas: o kit presente tem body + naninha
        bebe["subcategorias"][k:k] = [
            {"nome": "Sapatinhos", "palavras": ["sapatinho", "sapatilha", "tênis bebê", "botina", "mocassim"]},
            {"nome": "Roupinhas", "palavras": ["body", "bodies", "mijão", "macacão", "macacões", "vestido bebê",
                                               "regatas", "kit roupa de bebê", "roupa bebê", "conjunto bebê"]},
        ]
        bebe["intro"] = ("Enxoval, roupinhas, sapatinhos, mantas, sacos de dormir, trocadores, naninhas e móbiles para os "
                         "primeiros meses do bebê, selecionados entre os mais vendidos e bem avaliados do Mercado Livre.")
        bebe["chamada"] = "enxoval, roupinhas, sapatinhos e naninhas"
    if not any(c["slug"] == "moda-infantil-e-juvenil" for c in cats):
        moda = {
            "nome": "Moda Infantil & Juvenil", "slug": "moda-infantil-e-juvenil", "emoji": "👕",
            "intro": ("Kits de conjuntos, moletons, macaquinhos, calcinhas e meias para meninas e meninos do infantil ao "
                      "juvenil, selecionados entre os mais vendidos e bem avaliados do Mercado Livre."),
            "chamada": "conjuntos, moletons e kits para meninas e meninos",
            "meta_descricao": ("Kits de roupa infantil e juvenil: conjuntos de verão, moletons, macaquinhos, calcinhas e "
                               "meias para meninas e meninos, os mais vendidos do Mercado Livre."),
            "subcategorias": [
                {"nome": "Moletons", "palavras": ["moletom", "moletons"]},
                {"nome": "Calcinhas & Meias", "palavras": ["calcinha", "calcinhas", "meia", "meias"]},
                {"nome": "Meninas", "palavras": ["menina", "feminino", "feminina", "vestido de festa"]},
                {"nome": "Meninos", "palavras": ["menino", "masculino"]},
                {"nome": "Mais Moda Infantil", "palavras": ["infantil", "juvenil", "kids"]},
            ],
        }
        assert len(moda["meta_descricao"]) <= 160, len(moda["meta_descricao"])
        k = next(i for i, c in enumerate(cats) if c["slug"] == "bebe-e-maternidade") + 1
        cats.insert(k, moda)
    json.dump(d, open(F, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    depois = mapa()
    mud = [(n, antes[n], depois[n]) for n in antes if n <= 160 and antes[n] != depois[n]]
    print("itens 1-160 que mudaram:", mud or "nenhum")
    antes = depois
for x in it:
    if x["n"] > 160 or antes[x["n"]][0] is None:
        print(x["n"], x["nome"], "=>", " / ".join(str(v) for v in antes[x["n"]]))
