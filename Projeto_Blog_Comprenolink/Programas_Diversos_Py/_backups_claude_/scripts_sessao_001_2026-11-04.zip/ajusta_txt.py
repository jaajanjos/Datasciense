import sys
f = sys.argv[1]; t = open(f, encoding="utf-8").read()
R = [('"Quem dorme de lado ou de costas"', '"Quarto de hóspedes"'),
 ('"Usa sentado, no sofá ou na cadeira"', '"Compacta: cabe em qualquer canto"'),
 ('"Pessoas idosas", "Assistir TV se movimentando"', '"Movimento no dia a dia", "Apartamento"'),
 ('["Praia e piscina", "Viagens", "Banho", "Presente"]', '["Praia e piscina", "Viagens", "Churrasco", "Presente"]'),
 ('com 2 baterias de 2.0 Ah, carregador bivolt e kit', 'com 2 baterias de 2.0 Ah, bivolt e kit')]
for a, b in R:
    assert t.count(a) == 1, a
    t = t.replace(a, b)
open(f, "w", encoding="utf-8").write(t); print("ok")
