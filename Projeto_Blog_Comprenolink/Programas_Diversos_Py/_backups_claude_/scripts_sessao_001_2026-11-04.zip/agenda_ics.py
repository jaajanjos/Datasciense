import uuid
from datetime import datetime

ARQ = r"D:\mercado_livre\Manutenção_Blog\3_DOCUMENTACAO\AGENDA_BLOG_2026.ics"
LINK = "https://comprenolink.net/black-friday/"
NATAL = "https://comprenolink.net/presentes-de-natal/"
# (data AAAAMMDD, hora HHMM, minutos, título, descrição, regra de repetição)
E = [
 ("20261027", "1000", 30, "Blog: Search Console - pedir indexação",
  "Site Kit > Search Console > Inspeção de URL: pedir indexação da Início, /black-friday/ e das 7 categorias. Em Sitemaps: enviar page-sitemap.xml.", ""),
 ("20261102", "1900", 30, "Blog: post no Instagram - Black Friday",
  f"Post de uma categoria ou produto do Top 10. Link na bio: {LINK}", "FREQ=WEEKLY;BYDAY=MO,WE,FR;UNTIL=20261120T235959Z"),
 ("20261103", "1200", 15, "Blog: mensagem nos grupos de WhatsApp",
  f"'Montei uma lista das ofertas que valem a pena acompanhar na Black Friday': {LINK}", ""),
 ("20261105", "1000", 30, "Blog: republicar blog das máquinas no Google Sites",
  "Republicar no Google Sites a versão sem preços (painel das máquinas).", ""),
 ("20261109", "1000", 30, "Blog: decidir pendências de estratégia",
  "1) Fone QCY da Shopee entra ou não. 2) Nota antiga 'Preços pesquisados em setembro' no painel das máquinas. 3) Divulgação de longo prazo (vídeos, importar vendas).", ""),
 ("20261123", "1900", 30, "Blog: semana da Black Friday - post + stories",
  f"Post e stories com produtos do Top 10. Link: {LINK}", "FREQ=DAILY;UNTIL=20261130T235959Z"),
 ("20261126", "2000", 15, "Blog: lembrete forte - amanhã é Black Friday",
  f"Stories + WhatsApp: 'amanhã é Black Friday, salve a lista'. {LINK}", ""),
 ("20261127", "0800", 15, "Blog: Black Friday - disparo da manhã", f"Stories + WhatsApp com o link: {LINK}", ""),
 ("20261127", "1200", 15, "Blog: Black Friday - disparo do almoço", f"Stories + WhatsApp com o link: {LINK}", ""),
 ("20261127", "1900", 15, "Blog: Black Friday - disparo da noite", f"Stories + WhatsApp com o link: {LINK}", ""),
 ("20261130", "1200", 15, "Blog: Cyber Monday - último reforço", f"Último dia da campanha Black Friday. {LINK}", ""),
 ("20261201", "0900", 30, "Blog: conferir troca para o Natal",
  f"Ver se 'Presentes de Natal' apareceu no menu ({NATAL}). Se não, pedir ao Claude 'gerar as categorias'. Search Console: pedir indexação de /presentes-de-natal/.", ""),
 ("20261202", "1900", 30, "Blog: post no Instagram - Presentes de Natal",
  f"Post de um presente do Top 10 de Natal. Link na bio: {NATAL}", "FREQ=WEEKLY;BYDAY=MO,WE,FR;UNTIL=20261223T235959Z"),
 ("20261228", "1000", 20, "Blog: próximo tema (Volta às aulas)",
  "Botão e faixa do Natal já saíram sozinhos. Decidir se pede ao Claude o tema 'Volta às aulas' para janeiro.", ""),
]
agora = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
L = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//comprenolink//agenda blog//PT", "CALSCALE:GREGORIAN",
     "BEGIN:VTIMEZONE", "TZID:America/Sao_Paulo", "BEGIN:STANDARD", "DTSTART:19700101T000000",
     "TZOFFSETFROM:-0300", "TZOFFSETTO:-0300", "TZNAME:-03", "END:STANDARD", "END:VTIMEZONE"]
esc = lambda t: t.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
for d, h, m, tit, desc, rr in E:
    hh, mm = int(h[:2]), int(h[2:]) + m
    fim = f"{d}T{hh + mm // 60:02d}{mm % 60:02d}00"
    L += ["BEGIN:VEVENT", f"UID:{uuid.uuid4()}@comprenolink", f"DTSTAMP:{agora}",
          f"DTSTART;TZID=America/Sao_Paulo:{d}T{h}00", f"DTEND;TZID=America/Sao_Paulo:{fim}",
          f"SUMMARY:{esc(tit)}", f"DESCRIPTION:{esc(desc)}"]
    if rr:
        L.append(f"RRULE:{rr}")
    L += ["BEGIN:VALARM", "ACTION:DISPLAY", f"DESCRIPTION:{esc(tit)}", "TRIGGER:-PT30M", "END:VALARM", "END:VEVENT"]
L.append("END:VCALENDAR")
with open(ARQ, "w", encoding="utf-8", newline="\r\n") as f:
    f.write("\n".join(L) + "\n")
print(ARQ, len(E), "eventos")
