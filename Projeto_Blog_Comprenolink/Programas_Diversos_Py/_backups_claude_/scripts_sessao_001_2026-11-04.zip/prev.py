import fitz, sys, os
P = r"D:\mercado_livre\3- DIVULGAÇÃO_WHATSAPP_INSTAGRAM"
for nome, pags in (("01_GUIA_COMPLETO_DIVULGACAO", [1, 3, 5, 8]), ("02_CHECKLISTS_IMPRIMIVEIS", [1, 5])):
    d = fitz.open(os.path.join(P, nome + ".pdf")); print(nome, d.page_count)
    for i in pags:
        if i < d.page_count:
            d[i].get_pixmap(dpi=70).save(os.path.join(sys.argv[1], f"{nome[:2]}_p{i+1}.png"))
