T = {
 133: ("VITAMINA K2 Mk7", dict(nome="Vitamina K2 MK-7 Essencial Labs 60 Cápsulas", selo="K2 na Forma MK-7",
   desc="Vitamina K2 na forma MK-7 (menaquinona-7): suplemento Essencial Labs em frasco com 60 cápsulas, prático para a rotina.",
   beneficios=["Vitamina K2 na forma MK-7", "Menaquinona-7", "Frasco com 60 cápsulas", "Marca Essencial Labs"],
   ideal=["Complementar a alimentação", "Rotina de suplementação", "Combinar com a vitamina D", "Uso contínuo"],
   titulo_anuncio="Vitamina K2 MK-7 Menaquinona-7 Essencial Labs – 60 Cápsulas")),
}
