import json, os, sys
sys.path.insert(0, r"D:\mercado_livre\Manutenção_Blog\1_PROGRAMAS\Blog_WordPress")
import gerenciar_blog as gb
from publicar_categorias import salva_backup
META = "Celulares, Smart TVs, fones, ferramentas, enxoval, perfumes e fitness: ofertas selecionadas do Mercado Livre, organizadas por categoria para você escolher."
cfg = gb.carregar_config()
d = gb.requisitar(cfg, "GET", "/wp-json/wp/v2/pages/14?context=edit")
print("backup:", salva_backup("pagina14_inicio", d["content"]["raw"]))
antes = (d.get("aioseo_meta_data") or {}).get("description")
arq = os.path.join(gb.PASTA_BACKUP, "pagina14_inicio_meta_antes.json")
json.dump({"description": antes}, open(arq, "w", encoding="utf-8"), ensure_ascii=False)
print("meta antes:", repr(antes), "->", arq)
r = gb.requisitar(cfg, "POST", "/wp-json/wp/v2/pages/14", {"aioseo_meta_data": {"description": META}})
print("meta depois:", (r.get("aioseo_meta_data") or {}).get("description"))
