import subprocess, os, time, shutil
from PIL import Image
S = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(S, "fotos119"); os.makedirs(out, exist_ok=True)
C = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
dest = r"D:\mercado_livre\Manutenção_Blog\3_DOCUMENTACAO\Blog_WordPress\fotos_119_produtos_2026-10-25"
for p in ["tecnologia-e-informatica", "audio-e-tv", "ferramentas-e-utilidades", "esporte-e-fitness", "black-friday"]:
    png = os.path.join(out, p + ".png")
    subprocess.run([C, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--window-size=1280,4200",
                    "--user-data-dir=" + os.path.join(S, "chr"), "--screenshot=" + png,
                    f"https://comprenolink.net/{p}/?v={int(time.time())}"], capture_output=True, timeout=120)
    im = Image.open(png).convert("RGB"); jpg = os.path.join(out, p + ".jpg"); im.save(jpg, quality=80)
    shutil.copy2(jpg, os.path.join(dest, p + ".jpg")); print(p, im.size)
