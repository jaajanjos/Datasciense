import json, openpyxl
S = r"C:\Users\SVR_RYZEN_JAA\AppData\Local\Temp\claude\C--Users-SVR-RYZEN-JAA\d759a442-1d58-4e20-94e0-f2e7cc22f60c\scratchpad\links_cnl.json"
dados = {d["cod"]: d for d in json.load(open(S, encoding="utf-8"))}
B = r"D:\Mercado_Livre\4- Celular_Whatsapp\06_CATALOGO_WHATSAPP"
BASE = "https://comprenolink.net/melhores-produtos-mercado-livre-2026/#item-"
# produtos: link curto (cabe nos 75 caracteres do campo do WhatsApp) e cadastrado = S
f = B + r"\CATALOGO_WHATSAPP.xlsx"
wb = openpyxl.load_workbook(f); ws = wb.active; n = 0
for r in ws.iter_rows(min_row=2):
    cod = r[0].value
    if cod in dados:
        r[7].value = "S"
        if dados[cod]["acao"] in ("TROCAR", "OK"):
            r[4].value = BASE + str(dados[cod]["novo"]); n += 1
wb.save(f); print("produtos: links curtos gravados:", n)
# categorias: so Moda Infantil e Bebe existem no WhatsApp (conferido em 01/11)
f = B + r"\CATEGORIAS\CATALOGO_CATEGORIAS.xlsx"
wb = openpyxl.load_workbook(f); ws = wb.active
for r in ws.iter_rows(min_row=2):
    cod = str(r[0].value or "")
    if cod.startswith("CAT-"):
        r[7].value = "S" if cod in ("CAT-moda-infantil-e-juvenil", "CAT-bebe-e-maternidade") else "N"
wb.save(f)
wb = openpyxl.load_workbook(f)
print([(r[0].value[4:20], r[7].value) for r in wb.active.iter_rows(min_row=2)])
