import sys; sys.stdout.reconfigure(encoding="utf-8")
import sys, os, re, html
sys.path.insert(0, sys.argv[1])
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gerenciar_blog as g
from textos_139a140 import T

cfg = g.carregar_config()
p = g.baixar_pagina(cfg)
print("página lida, modificada em", p.modificado)
antes = {x["n"]: x for x in g.itens(p.conteudo)}
s = p.conteudo
for n, (comeco, c) in T.items():
    assert antes[n]["nome"].startswith(comeco), f"item {n} mudou: {antes[n]['nome']}"
    s, av = g.editar_item(s, n, c)
    assert not av, (n, av)
    x = g._sec(s, n); t = s[x["ini"]:x["fim"]]
    t2, _ = re.subn(r'(<img\b[^>]*\balt=")[^"]*(")', lambda m: m.group(1) + html.escape(c["titulo_anuncio"]) + m.group(2), t, count=1)
    s = s[:x["ini"]] + t2 + s[x["fim"]:]
assert not g.verificar(s), g.verificar(s)
g.publicar(cfg, p, s, p.titulo)
depois = {x["n"]: x for x in g.itens(g.baixar_pagina(cfg).conteudo)}
ok = all(all(depois[n][k] == v for k, v in c.items()) for n, (_, c) in T.items())
links = all(depois[n]["link"] == antes[n]["link"] and depois[n]["imagem"] == antes[n]["imagem"] for n in antes)
intactos = all(depois[n] == antes[n] for n in antes if n not in T)
print("itens 139-140 no ar:", ok, "| links e fotos iguais:", links, "| itens 1-138 intactos:", intactos, "| total:", len(depois))
