import sys, os, shutil, re
from datetime import date
FONTE = "D:/mercado_livre/3- Divugação_WhastsApp_Instagram/_fonte"
sys.path.insert(0, FONTE); os.chdir(FONTE)
import dados_divulgacao as dd
import gerar_artes_catalogo as ga
import gerar_reels
BK = os.path.join(os.path.dirname(ga.PACOTE), "_backup_pacotes")
dados = dd.carrega_produtos()
orig = dd.calendario
ja = {date(2026,11,25), date(2026,11,26), date(2026,11,28), date(2026,12,16)}
alvo = sorted({l["data"] for l in orig(dados) if l["item"] and l["data"] not in ja})
nome = lambda d: f"{d:%Y-%m-%d}_{ga.DIAS[d.weekday()]}"
titulo = lambda p: open(os.path.join(p,"1_TEXTOS_DO_DIA.txt"),encoding="utf-8-sig").read().split("🔥",1)[1].split("\n")[0].strip() if os.path.exists(os.path.join(p,"1_TEXTOS_DO_DIA.txt")) and "🔥" in open(os.path.join(p,"1_TEXTOS_DO_DIA.txt"),encoding="utf-8-sig").read() else None
ok, ruim = [], []
for d in alvo:
    p = os.path.join(ga.PACOTE, nome(d))
    if not os.path.isdir(p): ruim.append((d,"sem pasta")); continue
    ant = titulo(p)
    bk = os.path.join(BK, nome(d)+"_30out_ANTES_refazer")
    if not os.path.exists(bk): shutil.copytree(p, bk)
    f = lambda dados_, d=d: [l for l in orig(dados_) if l["data"] == d]
    dd.calendario = f; ga.dd.calendario = f
    ga.gera_pacotes(dados)
    novo = titulo(p)
    if ant and novo and ant != novo:
        ruim.append((d, f"produto mudou: {ant!r} -> {novo!r}"))
        shutil.rmtree(p); shutil.copytree(bk, p); continue
    if os.path.exists(os.path.join(p,"reels.mp4")):
        gerar_reels.gera(p)
    ok.append((d, novo))
dd.calendario = orig
# 16/12: só o Reels (pacote já trocado em 30/10)
p16 = os.path.join(ga.PACOTE, "2026-12-16_qua")
bk = os.path.join(BK, "2026-12-16_qua_30out_ANTES_reels")
if not os.path.exists(bk): shutil.copytree(p16, bk)
gerar_reels.gera(p16)
print("OK:", len(ok)); [print(" ", d, t) for d, t in ok]
print("PROBLEMAS:", ruim)
