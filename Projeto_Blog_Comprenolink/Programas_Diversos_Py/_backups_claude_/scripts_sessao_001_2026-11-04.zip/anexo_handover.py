import importlib.util, sys
sys.stdout.reconfigure(encoding="utf-8")
P = "D:/mercado_livre/0- Pendencias/99_Programas_PY/gerar_relatorio_atividade.py"
spec = importlib.util.spec_from_file_location("rel", P)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
EX, PA, NE = m.EX, m.PA, m.NE
nome = {EX: "FEITO", PA: "PARCIAL", NE: "NÃO FEITO"}
L = ["# ANEXO DO HANDOVER 001 → 000: histórico completo, ajustes, decisões e pendências (gerado em 04/11/2026)",
     "Fonte: lista ATIVIDADES/FALTA_AGENDAR/REEXECUCAO/OBSERVACOES de `0- Pendencias/99_Programas_PY/gerar_relatorio_atividade.py` (registro auditável do que a conversa 001 e a 000 fizeram, com motivo e conferência).",
     "Leia junto com `HANDOVER_TECNICO_001_para_000_2026-11-04.md`. Transcrição integral da 001: `C:\\Users\\SVR_RYZEN_JAA\\.claude\\projects\\C--Users-SVR-RYZEN-JAA\\d759a442-1d58-4e20-94e0-f2e7cc22f60c.jsonl`.", ""]
L += ["## A. Decisões e preferências do dono (valem sempre)",
      "- Responder sempre em PT-BR, com passos simples. Gerar/atualizar o relatório PDF ao fim de toda sessão e enviá-lo; avisar quando a atividade do dia terminar.",
      "- Textos dos produtos: atrativos, mas sem preço, sem \"melhor/menor preço\", sem \"mais vendido/líder/oferta do mês\", sem \"garantido\", sem promessa de saúde ou estética, só fatos do título do anúncio, com aviso de afiliado.",
      "- Respeitar a estrutura oficial de pastas (nada solto na raiz; perguntar antes de criar pasta).",
      "- Rotina diária de agendamento do Instagram aprovada em 29/10/2026 (post 19:00 + Reels 19:05, legenda do 2_LEGENDA_REELS.txt sem título e sem ====).",
      "- Alterações no blog sempre com backup; não apagar nada irreversível (catálogo do WhatsApp, itens) sem o dono.",
      "- Senhas: o Claude nunca digita. Instagram logado só no Chrome \"Browser 1\"; WhatsApp Web só com o dono conectando (QR).",
      "- Em 04/11 o dono decidiu trabalhar só na conversa 000 e passou para ela o agendamento do Instagram; o cron a6d1f751 da 001 só sai depois de a 000 criar o dela.",
      "- Uso: recarga automática ligada (saldo ~R$ 74 em 31/10); preferir Sonnet para rotina; o limite semanal renova segunda às 02:00 (Brasília).", ""]
L += ["## B. Pendências atuais (como estavam no registro em 04/11)", "### B.1 Dias de post ainda sem agendar (FALTA_AGENDAR)"]
for d, p in m.FALTA_AGENDAR:
    L.append(f"- {d}: {p}")
L += ["", "### B.2 Reexecução e próximos passos (quando, quem, o que, observação)"]
for q, w, o, obs in m.REEXECUCAO:
    L.append(f"- **{q}** ({w}): {o}. _{obs}_")
L += ["", "### B.3 Observações gerais do registro"]
for o in m.OBSERVACOES:
    L.append(f"- {o}")
L += ["", "## C. Histórico de ajustes e atividades (ordem do registro)", "Legenda: FEITO / PARCIAL / NÃO FEITO. Entre parênteses o motivo e a nova data quando não concluído.", ""]
for a in m.ATIVIDADES:
    d, h, o, st, det = a[0], a[1], a[2], a[3], a[4]
    mot = a[5] if len(a) > 5 else ""
    nova = a[6] if len(a) > 6 else ""
    L.append(f"### {d} {h} — {nome.get(st, st)}: {o}")
    if det:
        L.append(det)
    if mot or nova:
        L.append(f"_Motivo/pendência: {mot} | Nova data: {nova}_")
    L.append("")
open("D:/mercado_livre/0- Pendencias/1_Pendencias/HANDOVER_TECNICO_001_para_000_ANEXO_historico_e_pendencias_2026-11-04.md", "w", encoding="utf-8").write("\n".join(L))
print("entradas:", len(m.ATIVIDADES), "| reexecucao:", len(m.REEXECUCAO), "| falta:", len(m.FALTA_AGENDAR), "| tamanho:", sum(len(x) for x in L))
